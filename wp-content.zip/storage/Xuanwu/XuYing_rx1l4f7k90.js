ByteZhenWenn.LobbyUICode = {};
ByteZhenWenn.LobbyUICode.localVariables = [];
ByteZhenWenn.LobbyUICode.GDGameBackgrondObjects1= [];
ByteZhenWenn.LobbyUICode.GDGameBackgrondObjects2= [];
ByteZhenWenn.LobbyUICode.GDGameBackgrondObjects3= [];
ByteZhenWenn.LobbyUICode.GDGameBackgrondObjects4= [];
ByteZhenWenn.LobbyUICode.GDGameBackgrondObjects5= [];
ByteZhenWenn.LobbyUICode.GDGameBackgrondObjects6= [];
ByteZhenWenn.LobbyUICode.GDGameBackgrondObjects7= [];
ByteZhenWenn.LobbyUICode.GDGameBackgrondObjects8= [];
ByteZhenWenn.LobbyUICode.GDLogoObjects1= [];
ByteZhenWenn.LobbyUICode.GDLogoObjects2= [];
ByteZhenWenn.LobbyUICode.GDLogoObjects3= [];
ByteZhenWenn.LobbyUICode.GDLogoObjects4= [];
ByteZhenWenn.LobbyUICode.GDLogoObjects5= [];
ByteZhenWenn.LobbyUICode.GDLogoObjects6= [];
ByteZhenWenn.LobbyUICode.GDLogoObjects7= [];
ByteZhenWenn.LobbyUICode.GDLogoObjects8= [];
ByteZhenWenn.LobbyUICode.GDHeader_9595UIObjects1= [];
ByteZhenWenn.LobbyUICode.GDHeader_9595UIObjects2= [];
ByteZhenWenn.LobbyUICode.GDHeader_9595UIObjects3= [];
ByteZhenWenn.LobbyUICode.GDHeader_9595UIObjects4= [];
ByteZhenWenn.LobbyUICode.GDHeader_9595UIObjects5= [];
ByteZhenWenn.LobbyUICode.GDHeader_9595UIObjects6= [];
ByteZhenWenn.LobbyUICode.GDHeader_9595UIObjects7= [];
ByteZhenWenn.LobbyUICode.GDHeader_9595UIObjects8= [];
ByteZhenWenn.LobbyUICode.GDPlayerIDObjects1= [];
ByteZhenWenn.LobbyUICode.GDPlayerIDObjects2= [];
ByteZhenWenn.LobbyUICode.GDPlayerIDObjects3= [];
ByteZhenWenn.LobbyUICode.GDPlayerIDObjects4= [];
ByteZhenWenn.LobbyUICode.GDPlayerIDObjects5= [];
ByteZhenWenn.LobbyUICode.GDPlayerIDObjects6= [];
ByteZhenWenn.LobbyUICode.GDPlayerIDObjects7= [];
ByteZhenWenn.LobbyUICode.GDPlayerIDObjects8= [];
ByteZhenWenn.LobbyUICode.GDPlayerBalanceObjects1= [];
ByteZhenWenn.LobbyUICode.GDPlayerBalanceObjects2= [];
ByteZhenWenn.LobbyUICode.GDPlayerBalanceObjects3= [];
ByteZhenWenn.LobbyUICode.GDPlayerBalanceObjects4= [];
ByteZhenWenn.LobbyUICode.GDPlayerBalanceObjects5= [];
ByteZhenWenn.LobbyUICode.GDPlayerBalanceObjects6= [];
ByteZhenWenn.LobbyUICode.GDPlayerBalanceObjects7= [];
ByteZhenWenn.LobbyUICode.GDPlayerBalanceObjects8= [];
ByteZhenWenn.LobbyUICode.GDIndiqueGanheObjects1= [];
ByteZhenWenn.LobbyUICode.GDIndiqueGanheObjects2= [];
ByteZhenWenn.LobbyUICode.GDIndiqueGanheObjects3= [];
ByteZhenWenn.LobbyUICode.GDIndiqueGanheObjects4= [];
ByteZhenWenn.LobbyUICode.GDIndiqueGanheObjects5= [];
ByteZhenWenn.LobbyUICode.GDIndiqueGanheObjects6= [];
ByteZhenWenn.LobbyUICode.GDIndiqueGanheObjects7= [];
ByteZhenWenn.LobbyUICode.GDIndiqueGanheObjects8= [];
ByteZhenWenn.LobbyUICode.GDGasObjects1= [];
ByteZhenWenn.LobbyUICode.GDGasObjects2= [];
ByteZhenWenn.LobbyUICode.GDGasObjects3= [];
ByteZhenWenn.LobbyUICode.GDGasObjects4= [];
ByteZhenWenn.LobbyUICode.GDGasObjects5= [];
ByteZhenWenn.LobbyUICode.GDGasObjects6= [];
ByteZhenWenn.LobbyUICode.GDGasObjects7= [];
ByteZhenWenn.LobbyUICode.GDGasObjects8= [];
ByteZhenWenn.LobbyUICode.GDNewSpriteObjects1= [];
ByteZhenWenn.LobbyUICode.GDNewSpriteObjects2= [];
ByteZhenWenn.LobbyUICode.GDNewSpriteObjects3= [];
ByteZhenWenn.LobbyUICode.GDNewSpriteObjects4= [];
ByteZhenWenn.LobbyUICode.GDNewSpriteObjects5= [];
ByteZhenWenn.LobbyUICode.GDNewSpriteObjects6= [];
ByteZhenWenn.LobbyUICode.GDNewSpriteObjects7= [];
ByteZhenWenn.LobbyUICode.GDNewSpriteObjects8= [];
ByteZhenWenn.LobbyUICode.GDUi_9595SOCIALObjects1= [];
ByteZhenWenn.LobbyUICode.GDUi_9595SOCIALObjects2= [];
ByteZhenWenn.LobbyUICode.GDUi_9595SOCIALObjects3= [];
ByteZhenWenn.LobbyUICode.GDUi_9595SOCIALObjects4= [];
ByteZhenWenn.LobbyUICode.GDUi_9595SOCIALObjects5= [];
ByteZhenWenn.LobbyUICode.GDUi_9595SOCIALObjects6= [];
ByteZhenWenn.LobbyUICode.GDUi_9595SOCIALObjects7= [];
ByteZhenWenn.LobbyUICode.GDUi_9595SOCIALObjects8= [];
ByteZhenWenn.LobbyUICode.GDUI_9595SupportObjects1= [];
ByteZhenWenn.LobbyUICode.GDUI_9595SupportObjects2= [];
ByteZhenWenn.LobbyUICode.GDUI_9595SupportObjects3= [];
ByteZhenWenn.LobbyUICode.GDUI_9595SupportObjects4= [];
ByteZhenWenn.LobbyUICode.GDUI_9595SupportObjects5= [];
ByteZhenWenn.LobbyUICode.GDUI_9595SupportObjects6= [];
ByteZhenWenn.LobbyUICode.GDUI_9595SupportObjects7= [];
ByteZhenWenn.LobbyUICode.GDUI_9595SupportObjects8= [];
ByteZhenWenn.LobbyUICode.GDSquirrelIdleObjects1= [];
ByteZhenWenn.LobbyUICode.GDSquirrelIdleObjects2= [];
ByteZhenWenn.LobbyUICode.GDSquirrelIdleObjects3= [];
ByteZhenWenn.LobbyUICode.GDSquirrelIdleObjects4= [];
ByteZhenWenn.LobbyUICode.GDSquirrelIdleObjects5= [];
ByteZhenWenn.LobbyUICode.GDSquirrelIdleObjects6= [];
ByteZhenWenn.LobbyUICode.GDSquirrelIdleObjects7= [];
ByteZhenWenn.LobbyUICode.GDSquirrelIdleObjects8= [];
ByteZhenWenn.LobbyUICode.GDPowerBallObjects1= [];
ByteZhenWenn.LobbyUICode.GDPowerBallObjects2= [];
ByteZhenWenn.LobbyUICode.GDPowerBallObjects3= [];
ByteZhenWenn.LobbyUICode.GDPowerBallObjects4= [];
ByteZhenWenn.LobbyUICode.GDPowerBallObjects5= [];
ByteZhenWenn.LobbyUICode.GDPowerBallObjects6= [];
ByteZhenWenn.LobbyUICode.GDPowerBallObjects7= [];
ByteZhenWenn.LobbyUICode.GDPowerBallObjects8= [];
ByteZhenWenn.LobbyUICode.GDBlueFlameObjects1= [];
ByteZhenWenn.LobbyUICode.GDBlueFlameObjects2= [];
ByteZhenWenn.LobbyUICode.GDBlueFlameObjects3= [];
ByteZhenWenn.LobbyUICode.GDBlueFlameObjects4= [];
ByteZhenWenn.LobbyUICode.GDBlueFlameObjects5= [];
ByteZhenWenn.LobbyUICode.GDBlueFlameObjects6= [];
ByteZhenWenn.LobbyUICode.GDBlueFlameObjects7= [];
ByteZhenWenn.LobbyUICode.GDBlueFlameObjects8= [];
ByteZhenWenn.LobbyUICode.GDSpinMainButtonObjects1= [];
ByteZhenWenn.LobbyUICode.GDSpinMainButtonObjects2= [];
ByteZhenWenn.LobbyUICode.GDSpinMainButtonObjects3= [];
ByteZhenWenn.LobbyUICode.GDSpinMainButtonObjects4= [];
ByteZhenWenn.LobbyUICode.GDSpinMainButtonObjects5= [];
ByteZhenWenn.LobbyUICode.GDSpinMainButtonObjects6= [];
ByteZhenWenn.LobbyUICode.GDSpinMainButtonObjects7= [];
ByteZhenWenn.LobbyUICode.GDSpinMainButtonObjects8= [];
ByteZhenWenn.LobbyUICode.GDNewSprite3Objects1= [];
ByteZhenWenn.LobbyUICode.GDNewSprite3Objects2= [];
ByteZhenWenn.LobbyUICode.GDNewSprite3Objects3= [];
ByteZhenWenn.LobbyUICode.GDNewSprite3Objects4= [];
ByteZhenWenn.LobbyUICode.GDNewSprite3Objects5= [];
ByteZhenWenn.LobbyUICode.GDNewSprite3Objects6= [];
ByteZhenWenn.LobbyUICode.GDNewSprite3Objects7= [];
ByteZhenWenn.LobbyUICode.GDNewSprite3Objects8= [];
ByteZhenWenn.LobbyUICode.GDSpinButtonObjects1= [];
ByteZhenWenn.LobbyUICode.GDSpinButtonObjects2= [];
ByteZhenWenn.LobbyUICode.GDSpinButtonObjects3= [];
ByteZhenWenn.LobbyUICode.GDSpinButtonObjects4= [];
ByteZhenWenn.LobbyUICode.GDSpinButtonObjects5= [];
ByteZhenWenn.LobbyUICode.GDSpinButtonObjects6= [];
ByteZhenWenn.LobbyUICode.GDSpinButtonObjects7= [];
ByteZhenWenn.LobbyUICode.GDSpinButtonObjects8= [];
ByteZhenWenn.LobbyUICode.GDPlusObjects1= [];
ByteZhenWenn.LobbyUICode.GDPlusObjects2= [];
ByteZhenWenn.LobbyUICode.GDPlusObjects3= [];
ByteZhenWenn.LobbyUICode.GDPlusObjects4= [];
ByteZhenWenn.LobbyUICode.GDPlusObjects5= [];
ByteZhenWenn.LobbyUICode.GDPlusObjects6= [];
ByteZhenWenn.LobbyUICode.GDPlusObjects7= [];
ByteZhenWenn.LobbyUICode.GDPlusObjects8= [];
ByteZhenWenn.LobbyUICode.GDMinusObjects1= [];
ByteZhenWenn.LobbyUICode.GDMinusObjects2= [];
ByteZhenWenn.LobbyUICode.GDMinusObjects3= [];
ByteZhenWenn.LobbyUICode.GDMinusObjects4= [];
ByteZhenWenn.LobbyUICode.GDMinusObjects5= [];
ByteZhenWenn.LobbyUICode.GDMinusObjects6= [];
ByteZhenWenn.LobbyUICode.GDMinusObjects7= [];
ByteZhenWenn.LobbyUICode.GDMinusObjects8= [];
ByteZhenWenn.LobbyUICode.GDBetAmountObjects1= [];
ByteZhenWenn.LobbyUICode.GDBetAmountObjects2= [];
ByteZhenWenn.LobbyUICode.GDBetAmountObjects3= [];
ByteZhenWenn.LobbyUICode.GDBetAmountObjects4= [];
ByteZhenWenn.LobbyUICode.GDBetAmountObjects5= [];
ByteZhenWenn.LobbyUICode.GDBetAmountObjects6= [];
ByteZhenWenn.LobbyUICode.GDBetAmountObjects7= [];
ByteZhenWenn.LobbyUICode.GDBetAmountObjects8= [];
ByteZhenWenn.LobbyUICode.GDWinAmountObjects1= [];
ByteZhenWenn.LobbyUICode.GDWinAmountObjects2= [];
ByteZhenWenn.LobbyUICode.GDWinAmountObjects3= [];
ByteZhenWenn.LobbyUICode.GDWinAmountObjects4= [];
ByteZhenWenn.LobbyUICode.GDWinAmountObjects5= [];
ByteZhenWenn.LobbyUICode.GDWinAmountObjects6= [];
ByteZhenWenn.LobbyUICode.GDWinAmountObjects7= [];
ByteZhenWenn.LobbyUICode.GDWinAmountObjects8= [];
ByteZhenWenn.LobbyUICode.GDLockObjects1= [];
ByteZhenWenn.LobbyUICode.GDLockObjects2= [];
ByteZhenWenn.LobbyUICode.GDLockObjects3= [];
ByteZhenWenn.LobbyUICode.GDLockObjects4= [];
ByteZhenWenn.LobbyUICode.GDLockObjects5= [];
ByteZhenWenn.LobbyUICode.GDLockObjects6= [];
ByteZhenWenn.LobbyUICode.GDLockObjects7= [];
ByteZhenWenn.LobbyUICode.GDLockObjects8= [];
ByteZhenWenn.LobbyUICode.GDSpinMagicObjects1= [];
ByteZhenWenn.LobbyUICode.GDSpinMagicObjects2= [];
ByteZhenWenn.LobbyUICode.GDSpinMagicObjects3= [];
ByteZhenWenn.LobbyUICode.GDSpinMagicObjects4= [];
ByteZhenWenn.LobbyUICode.GDSpinMagicObjects5= [];
ByteZhenWenn.LobbyUICode.GDSpinMagicObjects6= [];
ByteZhenWenn.LobbyUICode.GDSpinMagicObjects7= [];
ByteZhenWenn.LobbyUICode.GDSpinMagicObjects8= [];
ByteZhenWenn.LobbyUICode.GDPulseParticleObjects1= [];
ByteZhenWenn.LobbyUICode.GDPulseParticleObjects2= [];
ByteZhenWenn.LobbyUICode.GDPulseParticleObjects3= [];
ByteZhenWenn.LobbyUICode.GDPulseParticleObjects4= [];
ByteZhenWenn.LobbyUICode.GDPulseParticleObjects5= [];
ByteZhenWenn.LobbyUICode.GDPulseParticleObjects6= [];
ByteZhenWenn.LobbyUICode.GDPulseParticleObjects7= [];
ByteZhenWenn.LobbyUICode.GDPulseParticleObjects8= [];
ByteZhenWenn.LobbyUICode.GDChest1Objects1= [];
ByteZhenWenn.LobbyUICode.GDChest1Objects2= [];
ByteZhenWenn.LobbyUICode.GDChest1Objects3= [];
ByteZhenWenn.LobbyUICode.GDChest1Objects4= [];
ByteZhenWenn.LobbyUICode.GDChest1Objects5= [];
ByteZhenWenn.LobbyUICode.GDChest1Objects6= [];
ByteZhenWenn.LobbyUICode.GDChest1Objects7= [];
ByteZhenWenn.LobbyUICode.GDChest1Objects8= [];
ByteZhenWenn.LobbyUICode.GDChest2Objects1= [];
ByteZhenWenn.LobbyUICode.GDChest2Objects2= [];
ByteZhenWenn.LobbyUICode.GDChest2Objects3= [];
ByteZhenWenn.LobbyUICode.GDChest2Objects4= [];
ByteZhenWenn.LobbyUICode.GDChest2Objects5= [];
ByteZhenWenn.LobbyUICode.GDChest2Objects6= [];
ByteZhenWenn.LobbyUICode.GDChest2Objects7= [];
ByteZhenWenn.LobbyUICode.GDChest2Objects8= [];
ByteZhenWenn.LobbyUICode.GDChest3Objects1= [];
ByteZhenWenn.LobbyUICode.GDChest3Objects2= [];
ByteZhenWenn.LobbyUICode.GDChest3Objects3= [];
ByteZhenWenn.LobbyUICode.GDChest3Objects4= [];
ByteZhenWenn.LobbyUICode.GDChest3Objects5= [];
ByteZhenWenn.LobbyUICode.GDChest3Objects6= [];
ByteZhenWenn.LobbyUICode.GDChest3Objects7= [];
ByteZhenWenn.LobbyUICode.GDChest3Objects8= [];
ByteZhenWenn.LobbyUICode.GDChest4Objects1= [];
ByteZhenWenn.LobbyUICode.GDChest4Objects2= [];
ByteZhenWenn.LobbyUICode.GDChest4Objects3= [];
ByteZhenWenn.LobbyUICode.GDChest4Objects4= [];
ByteZhenWenn.LobbyUICode.GDChest4Objects5= [];
ByteZhenWenn.LobbyUICode.GDChest4Objects6= [];
ByteZhenWenn.LobbyUICode.GDChest4Objects7= [];
ByteZhenWenn.LobbyUICode.GDChest4Objects8= [];
ByteZhenWenn.LobbyUICode.GDChest5Objects1= [];
ByteZhenWenn.LobbyUICode.GDChest5Objects2= [];
ByteZhenWenn.LobbyUICode.GDChest5Objects3= [];
ByteZhenWenn.LobbyUICode.GDChest5Objects4= [];
ByteZhenWenn.LobbyUICode.GDChest5Objects5= [];
ByteZhenWenn.LobbyUICode.GDChest5Objects6= [];
ByteZhenWenn.LobbyUICode.GDChest5Objects7= [];
ByteZhenWenn.LobbyUICode.GDChest5Objects8= [];
ByteZhenWenn.LobbyUICode.GDChest6Objects1= [];
ByteZhenWenn.LobbyUICode.GDChest6Objects2= [];
ByteZhenWenn.LobbyUICode.GDChest6Objects3= [];
ByteZhenWenn.LobbyUICode.GDChest6Objects4= [];
ByteZhenWenn.LobbyUICode.GDChest6Objects5= [];
ByteZhenWenn.LobbyUICode.GDChest6Objects6= [];
ByteZhenWenn.LobbyUICode.GDChest6Objects7= [];
ByteZhenWenn.LobbyUICode.GDChest6Objects8= [];
ByteZhenWenn.LobbyUICode.GDChest7Objects1= [];
ByteZhenWenn.LobbyUICode.GDChest7Objects2= [];
ByteZhenWenn.LobbyUICode.GDChest7Objects3= [];
ByteZhenWenn.LobbyUICode.GDChest7Objects4= [];
ByteZhenWenn.LobbyUICode.GDChest7Objects5= [];
ByteZhenWenn.LobbyUICode.GDChest7Objects6= [];
ByteZhenWenn.LobbyUICode.GDChest7Objects7= [];
ByteZhenWenn.LobbyUICode.GDChest7Objects8= [];
ByteZhenWenn.LobbyUICode.GDChest8Objects1= [];
ByteZhenWenn.LobbyUICode.GDChest8Objects2= [];
ByteZhenWenn.LobbyUICode.GDChest8Objects3= [];
ByteZhenWenn.LobbyUICode.GDChest8Objects4= [];
ByteZhenWenn.LobbyUICode.GDChest8Objects5= [];
ByteZhenWenn.LobbyUICode.GDChest8Objects6= [];
ByteZhenWenn.LobbyUICode.GDChest8Objects7= [];
ByteZhenWenn.LobbyUICode.GDChest8Objects8= [];
ByteZhenWenn.LobbyUICode.GDChest9Objects1= [];
ByteZhenWenn.LobbyUICode.GDChest9Objects2= [];
ByteZhenWenn.LobbyUICode.GDChest9Objects3= [];
ByteZhenWenn.LobbyUICode.GDChest9Objects4= [];
ByteZhenWenn.LobbyUICode.GDChest9Objects5= [];
ByteZhenWenn.LobbyUICode.GDChest9Objects6= [];
ByteZhenWenn.LobbyUICode.GDChest9Objects7= [];
ByteZhenWenn.LobbyUICode.GDChest9Objects8= [];
ByteZhenWenn.LobbyUICode.GDChestExplosionObjects1= [];
ByteZhenWenn.LobbyUICode.GDChestExplosionObjects2= [];
ByteZhenWenn.LobbyUICode.GDChestExplosionObjects3= [];
ByteZhenWenn.LobbyUICode.GDChestExplosionObjects4= [];
ByteZhenWenn.LobbyUICode.GDChestExplosionObjects5= [];
ByteZhenWenn.LobbyUICode.GDChestExplosionObjects6= [];
ByteZhenWenn.LobbyUICode.GDChestExplosionObjects7= [];
ByteZhenWenn.LobbyUICode.GDChestExplosionObjects8= [];
ByteZhenWenn.LobbyUICode.GDSquirelBonusObjects1= [];
ByteZhenWenn.LobbyUICode.GDSquirelBonusObjects2= [];
ByteZhenWenn.LobbyUICode.GDSquirelBonusObjects3= [];
ByteZhenWenn.LobbyUICode.GDSquirelBonusObjects4= [];
ByteZhenWenn.LobbyUICode.GDSquirelBonusObjects5= [];
ByteZhenWenn.LobbyUICode.GDSquirelBonusObjects6= [];
ByteZhenWenn.LobbyUICode.GDSquirelBonusObjects7= [];
ByteZhenWenn.LobbyUICode.GDSquirelBonusObjects8= [];
ByteZhenWenn.LobbyUICode.GDLeafParticleObjects1= [];
ByteZhenWenn.LobbyUICode.GDLeafParticleObjects2= [];
ByteZhenWenn.LobbyUICode.GDLeafParticleObjects3= [];
ByteZhenWenn.LobbyUICode.GDLeafParticleObjects4= [];
ByteZhenWenn.LobbyUICode.GDLeafParticleObjects5= [];
ByteZhenWenn.LobbyUICode.GDLeafParticleObjects6= [];
ByteZhenWenn.LobbyUICode.GDLeafParticleObjects7= [];
ByteZhenWenn.LobbyUICode.GDLeafParticleObjects8= [];
ByteZhenWenn.LobbyUICode.GDsunlightObjects1= [];
ByteZhenWenn.LobbyUICode.GDsunlightObjects2= [];
ByteZhenWenn.LobbyUICode.GDsunlightObjects3= [];
ByteZhenWenn.LobbyUICode.GDsunlightObjects4= [];
ByteZhenWenn.LobbyUICode.GDsunlightObjects5= [];
ByteZhenWenn.LobbyUICode.GDsunlightObjects6= [];
ByteZhenWenn.LobbyUICode.GDsunlightObjects7= [];
ByteZhenWenn.LobbyUICode.GDsunlightObjects8= [];
ByteZhenWenn.LobbyUICode.GDMultiplierParticle2XObjects1= [];
ByteZhenWenn.LobbyUICode.GDMultiplierParticle2XObjects2= [];
ByteZhenWenn.LobbyUICode.GDMultiplierParticle2XObjects3= [];
ByteZhenWenn.LobbyUICode.GDMultiplierParticle2XObjects4= [];
ByteZhenWenn.LobbyUICode.GDMultiplierParticle2XObjects5= [];
ByteZhenWenn.LobbyUICode.GDMultiplierParticle2XObjects6= [];
ByteZhenWenn.LobbyUICode.GDMultiplierParticle2XObjects7= [];
ByteZhenWenn.LobbyUICode.GDMultiplierParticle2XObjects8= [];
ByteZhenWenn.LobbyUICode.GDMultiplierParticle5XObjects1= [];
ByteZhenWenn.LobbyUICode.GDMultiplierParticle5XObjects2= [];
ByteZhenWenn.LobbyUICode.GDMultiplierParticle5XObjects3= [];
ByteZhenWenn.LobbyUICode.GDMultiplierParticle5XObjects4= [];
ByteZhenWenn.LobbyUICode.GDMultiplierParticle5XObjects5= [];
ByteZhenWenn.LobbyUICode.GDMultiplierParticle5XObjects6= [];
ByteZhenWenn.LobbyUICode.GDMultiplierParticle5XObjects7= [];
ByteZhenWenn.LobbyUICode.GDMultiplierParticle5XObjects8= [];
ByteZhenWenn.LobbyUICode.GDMultiplierParticle10XObjects1= [];
ByteZhenWenn.LobbyUICode.GDMultiplierParticle10XObjects2= [];
ByteZhenWenn.LobbyUICode.GDMultiplierParticle10XObjects3= [];
ByteZhenWenn.LobbyUICode.GDMultiplierParticle10XObjects4= [];
ByteZhenWenn.LobbyUICode.GDMultiplierParticle10XObjects5= [];
ByteZhenWenn.LobbyUICode.GDMultiplierParticle10XObjects6= [];
ByteZhenWenn.LobbyUICode.GDMultiplierParticle10XObjects7= [];
ByteZhenWenn.LobbyUICode.GDMultiplierParticle10XObjects8= [];
ByteZhenWenn.LobbyUICode.GDMultiplierParticle3XObjects1= [];
ByteZhenWenn.LobbyUICode.GDMultiplierParticle3XObjects2= [];
ByteZhenWenn.LobbyUICode.GDMultiplierParticle3XObjects3= [];
ByteZhenWenn.LobbyUICode.GDMultiplierParticle3XObjects4= [];
ByteZhenWenn.LobbyUICode.GDMultiplierParticle3XObjects5= [];
ByteZhenWenn.LobbyUICode.GDMultiplierParticle3XObjects6= [];
ByteZhenWenn.LobbyUICode.GDMultiplierParticle3XObjects7= [];
ByteZhenWenn.LobbyUICode.GDMultiplierParticle3XObjects8= [];
ByteZhenWenn.LobbyUICode.GDNewLightObjects1= [];
ByteZhenWenn.LobbyUICode.GDNewLightObjects2= [];
ByteZhenWenn.LobbyUICode.GDNewLightObjects3= [];
ByteZhenWenn.LobbyUICode.GDNewLightObjects4= [];
ByteZhenWenn.LobbyUICode.GDNewLightObjects5= [];
ByteZhenWenn.LobbyUICode.GDNewLightObjects6= [];
ByteZhenWenn.LobbyUICode.GDNewLightObjects7= [];
ByteZhenWenn.LobbyUICode.GDNewLightObjects8= [];
ByteZhenWenn.LobbyUICode.GDDepositButtonObjects1= [];
ByteZhenWenn.LobbyUICode.GDDepositButtonObjects2= [];
ByteZhenWenn.LobbyUICode.GDDepositButtonObjects3= [];
ByteZhenWenn.LobbyUICode.GDDepositButtonObjects4= [];
ByteZhenWenn.LobbyUICode.GDDepositButtonObjects5= [];
ByteZhenWenn.LobbyUICode.GDDepositButtonObjects6= [];
ByteZhenWenn.LobbyUICode.GDDepositButtonObjects7= [];
ByteZhenWenn.LobbyUICode.GDDepositButtonObjects8= [];
ByteZhenWenn.LobbyUICode.GDBetModalObjects1= [];
ByteZhenWenn.LobbyUICode.GDBetModalObjects2= [];
ByteZhenWenn.LobbyUICode.GDBetModalObjects3= [];
ByteZhenWenn.LobbyUICode.GDBetModalObjects4= [];
ByteZhenWenn.LobbyUICode.GDBetModalObjects5= [];
ByteZhenWenn.LobbyUICode.GDBetModalObjects6= [];
ByteZhenWenn.LobbyUICode.GDBetModalObjects7= [];
ByteZhenWenn.LobbyUICode.GDBetModalObjects8= [];
ByteZhenWenn.LobbyUICode.GDWinModalObjects1= [];
ByteZhenWenn.LobbyUICode.GDWinModalObjects2= [];
ByteZhenWenn.LobbyUICode.GDWinModalObjects3= [];
ByteZhenWenn.LobbyUICode.GDWinModalObjects4= [];
ByteZhenWenn.LobbyUICode.GDWinModalObjects5= [];
ByteZhenWenn.LobbyUICode.GDWinModalObjects6= [];
ByteZhenWenn.LobbyUICode.GDWinModalObjects7= [];
ByteZhenWenn.LobbyUICode.GDWinModalObjects8= [];
ByteZhenWenn.LobbyUICode.GDui_9595rulesObjects1= [];
ByteZhenWenn.LobbyUICode.GDui_9595rulesObjects2= [];
ByteZhenWenn.LobbyUICode.GDui_9595rulesObjects3= [];
ByteZhenWenn.LobbyUICode.GDui_9595rulesObjects4= [];
ByteZhenWenn.LobbyUICode.GDui_9595rulesObjects5= [];
ByteZhenWenn.LobbyUICode.GDui_9595rulesObjects6= [];
ByteZhenWenn.LobbyUICode.GDui_9595rulesObjects7= [];
ByteZhenWenn.LobbyUICode.GDui_9595rulesObjects8= [];
ByteZhenWenn.LobbyUICode.GDui_9595rules_9595txtObjects1= [];
ByteZhenWenn.LobbyUICode.GDui_9595rules_9595txtObjects2= [];
ByteZhenWenn.LobbyUICode.GDui_9595rules_9595txtObjects3= [];
ByteZhenWenn.LobbyUICode.GDui_9595rules_9595txtObjects4= [];
ByteZhenWenn.LobbyUICode.GDui_9595rules_9595txtObjects5= [];
ByteZhenWenn.LobbyUICode.GDui_9595rules_9595txtObjects6= [];
ByteZhenWenn.LobbyUICode.GDui_9595rules_9595txtObjects7= [];
ByteZhenWenn.LobbyUICode.GDui_9595rules_9595txtObjects8= [];
ByteZhenWenn.LobbyUICode.GDui_9595soundObjects1= [];
ByteZhenWenn.LobbyUICode.GDui_9595soundObjects2= [];
ByteZhenWenn.LobbyUICode.GDui_9595soundObjects3= [];
ByteZhenWenn.LobbyUICode.GDui_9595soundObjects4= [];
ByteZhenWenn.LobbyUICode.GDui_9595soundObjects5= [];
ByteZhenWenn.LobbyUICode.GDui_9595soundObjects6= [];
ByteZhenWenn.LobbyUICode.GDui_9595soundObjects7= [];
ByteZhenWenn.LobbyUICode.GDui_9595soundObjects8= [];
ByteZhenWenn.LobbyUICode.GDui_9595sound_9595txtObjects1= [];
ByteZhenWenn.LobbyUICode.GDui_9595sound_9595txtObjects2= [];
ByteZhenWenn.LobbyUICode.GDui_9595sound_9595txtObjects3= [];
ByteZhenWenn.LobbyUICode.GDui_9595sound_9595txtObjects4= [];
ByteZhenWenn.LobbyUICode.GDui_9595sound_9595txtObjects5= [];
ByteZhenWenn.LobbyUICode.GDui_9595sound_9595txtObjects6= [];
ByteZhenWenn.LobbyUICode.GDui_9595sound_9595txtObjects7= [];
ByteZhenWenn.LobbyUICode.GDui_9595sound_9595txtObjects8= [];
ByteZhenWenn.LobbyUICode.GDGoldKeyObjects1= [];
ByteZhenWenn.LobbyUICode.GDGoldKeyObjects2= [];
ByteZhenWenn.LobbyUICode.GDGoldKeyObjects3= [];
ByteZhenWenn.LobbyUICode.GDGoldKeyObjects4= [];
ByteZhenWenn.LobbyUICode.GDGoldKeyObjects5= [];
ByteZhenWenn.LobbyUICode.GDGoldKeyObjects6= [];
ByteZhenWenn.LobbyUICode.GDGoldKeyObjects7= [];
ByteZhenWenn.LobbyUICode.GDGoldKeyObjects8= [];
ByteZhenWenn.LobbyUICode.GDProfileObjects1= [];
ByteZhenWenn.LobbyUICode.GDProfileObjects2= [];
ByteZhenWenn.LobbyUICode.GDProfileObjects3= [];
ByteZhenWenn.LobbyUICode.GDProfileObjects4= [];
ByteZhenWenn.LobbyUICode.GDProfileObjects5= [];
ByteZhenWenn.LobbyUICode.GDProfileObjects6= [];
ByteZhenWenn.LobbyUICode.GDProfileObjects7= [];
ByteZhenWenn.LobbyUICode.GDProfileObjects8= [];
ByteZhenWenn.LobbyUICode.GDPerfilObjects1= [];
ByteZhenWenn.LobbyUICode.GDPerfilObjects2= [];
ByteZhenWenn.LobbyUICode.GDPerfilObjects3= [];
ByteZhenWenn.LobbyUICode.GDPerfilObjects4= [];
ByteZhenWenn.LobbyUICode.GDPerfilObjects5= [];
ByteZhenWenn.LobbyUICode.GDPerfilObjects6= [];
ByteZhenWenn.LobbyUICode.GDPerfilObjects7= [];
ByteZhenWenn.LobbyUICode.GDPerfilObjects8= [];
ByteZhenWenn.LobbyUICode.GDprize_959500Objects1= [];
ByteZhenWenn.LobbyUICode.GDprize_959500Objects2= [];
ByteZhenWenn.LobbyUICode.GDprize_959500Objects3= [];
ByteZhenWenn.LobbyUICode.GDprize_959500Objects4= [];
ByteZhenWenn.LobbyUICode.GDprize_959500Objects5= [];
ByteZhenWenn.LobbyUICode.GDprize_959500Objects6= [];
ByteZhenWenn.LobbyUICode.GDprize_959500Objects7= [];
ByteZhenWenn.LobbyUICode.GDprize_959500Objects8= [];
ByteZhenWenn.LobbyUICode.GDprize_959501Objects1= [];
ByteZhenWenn.LobbyUICode.GDprize_959501Objects2= [];
ByteZhenWenn.LobbyUICode.GDprize_959501Objects3= [];
ByteZhenWenn.LobbyUICode.GDprize_959501Objects4= [];
ByteZhenWenn.LobbyUICode.GDprize_959501Objects5= [];
ByteZhenWenn.LobbyUICode.GDprize_959501Objects6= [];
ByteZhenWenn.LobbyUICode.GDprize_959501Objects7= [];
ByteZhenWenn.LobbyUICode.GDprize_959501Objects8= [];
ByteZhenWenn.LobbyUICode.GDprize_959502Objects1= [];
ByteZhenWenn.LobbyUICode.GDprize_959502Objects2= [];
ByteZhenWenn.LobbyUICode.GDprize_959502Objects3= [];
ByteZhenWenn.LobbyUICode.GDprize_959502Objects4= [];
ByteZhenWenn.LobbyUICode.GDprize_959502Objects5= [];
ByteZhenWenn.LobbyUICode.GDprize_959502Objects6= [];
ByteZhenWenn.LobbyUICode.GDprize_959502Objects7= [];
ByteZhenWenn.LobbyUICode.GDprize_959502Objects8= [];
ByteZhenWenn.LobbyUICode.GDprize_959503Objects1= [];
ByteZhenWenn.LobbyUICode.GDprize_959503Objects2= [];
ByteZhenWenn.LobbyUICode.GDprize_959503Objects3= [];
ByteZhenWenn.LobbyUICode.GDprize_959503Objects4= [];
ByteZhenWenn.LobbyUICode.GDprize_959503Objects5= [];
ByteZhenWenn.LobbyUICode.GDprize_959503Objects6= [];
ByteZhenWenn.LobbyUICode.GDprize_959503Objects7= [];
ByteZhenWenn.LobbyUICode.GDprize_959503Objects8= [];
ByteZhenWenn.LobbyUICode.GDprize_959504Objects1= [];
ByteZhenWenn.LobbyUICode.GDprize_959504Objects2= [];
ByteZhenWenn.LobbyUICode.GDprize_959504Objects3= [];
ByteZhenWenn.LobbyUICode.GDprize_959504Objects4= [];
ByteZhenWenn.LobbyUICode.GDprize_959504Objects5= [];
ByteZhenWenn.LobbyUICode.GDprize_959504Objects6= [];
ByteZhenWenn.LobbyUICode.GDprize_959504Objects7= [];
ByteZhenWenn.LobbyUICode.GDprize_959504Objects8= [];
ByteZhenWenn.LobbyUICode.GDcoin_9595particleObjects1= [];
ByteZhenWenn.LobbyUICode.GDcoin_9595particleObjects2= [];
ByteZhenWenn.LobbyUICode.GDcoin_9595particleObjects3= [];
ByteZhenWenn.LobbyUICode.GDcoin_9595particleObjects4= [];
ByteZhenWenn.LobbyUICode.GDcoin_9595particleObjects5= [];
ByteZhenWenn.LobbyUICode.GDcoin_9595particleObjects6= [];
ByteZhenWenn.LobbyUICode.GDcoin_9595particleObjects7= [];
ByteZhenWenn.LobbyUICode.GDcoin_9595particleObjects8= [];
ByteZhenWenn.LobbyUICode.GDcoin_9595trailObjects1= [];
ByteZhenWenn.LobbyUICode.GDcoin_9595trailObjects2= [];
ByteZhenWenn.LobbyUICode.GDcoin_9595trailObjects3= [];
ByteZhenWenn.LobbyUICode.GDcoin_9595trailObjects4= [];
ByteZhenWenn.LobbyUICode.GDcoin_9595trailObjects5= [];
ByteZhenWenn.LobbyUICode.GDcoin_9595trailObjects6= [];
ByteZhenWenn.LobbyUICode.GDcoin_9595trailObjects7= [];
ByteZhenWenn.LobbyUICode.GDcoin_9595trailObjects8= [];
ByteZhenWenn.LobbyUICode.GDprize_9595foxObjects1= [];
ByteZhenWenn.LobbyUICode.GDprize_9595foxObjects2= [];
ByteZhenWenn.LobbyUICode.GDprize_9595foxObjects3= [];
ByteZhenWenn.LobbyUICode.GDprize_9595foxObjects4= [];
ByteZhenWenn.LobbyUICode.GDprize_9595foxObjects5= [];
ByteZhenWenn.LobbyUICode.GDprize_9595foxObjects6= [];
ByteZhenWenn.LobbyUICode.GDprize_9595foxObjects7= [];
ByteZhenWenn.LobbyUICode.GDprize_9595foxObjects8= [];
ByteZhenWenn.LobbyUICode.GDFoxHitObjects1= [];
ByteZhenWenn.LobbyUICode.GDFoxHitObjects2= [];
ByteZhenWenn.LobbyUICode.GDFoxHitObjects3= [];
ByteZhenWenn.LobbyUICode.GDFoxHitObjects4= [];
ByteZhenWenn.LobbyUICode.GDFoxHitObjects5= [];
ByteZhenWenn.LobbyUICode.GDFoxHitObjects6= [];
ByteZhenWenn.LobbyUICode.GDFoxHitObjects7= [];
ByteZhenWenn.LobbyUICode.GDFoxHitObjects8= [];
ByteZhenWenn.LobbyUICode.GDChestCollectObjects1= [];
ByteZhenWenn.LobbyUICode.GDChestCollectObjects2= [];
ByteZhenWenn.LobbyUICode.GDChestCollectObjects3= [];
ByteZhenWenn.LobbyUICode.GDChestCollectObjects4= [];
ByteZhenWenn.LobbyUICode.GDChestCollectObjects5= [];
ByteZhenWenn.LobbyUICode.GDChestCollectObjects6= [];
ByteZhenWenn.LobbyUICode.GDChestCollectObjects7= [];
ByteZhenWenn.LobbyUICode.GDChestCollectObjects8= [];
ByteZhenWenn.LobbyUICode.GDcollect_9595textObjects1= [];
ByteZhenWenn.LobbyUICode.GDcollect_9595textObjects2= [];
ByteZhenWenn.LobbyUICode.GDcollect_9595textObjects3= [];
ByteZhenWenn.LobbyUICode.GDcollect_9595textObjects4= [];
ByteZhenWenn.LobbyUICode.GDcollect_9595textObjects5= [];
ByteZhenWenn.LobbyUICode.GDcollect_9595textObjects6= [];
ByteZhenWenn.LobbyUICode.GDcollect_9595textObjects7= [];
ByteZhenWenn.LobbyUICode.GDcollect_9595textObjects8= [];
ByteZhenWenn.LobbyUICode.GDBonusGreenBallObjects1= [];
ByteZhenWenn.LobbyUICode.GDBonusGreenBallObjects2= [];
ByteZhenWenn.LobbyUICode.GDBonusGreenBallObjects3= [];
ByteZhenWenn.LobbyUICode.GDBonusGreenBallObjects4= [];
ByteZhenWenn.LobbyUICode.GDBonusGreenBallObjects5= [];
ByteZhenWenn.LobbyUICode.GDBonusGreenBallObjects6= [];
ByteZhenWenn.LobbyUICode.GDBonusGreenBallObjects7= [];
ByteZhenWenn.LobbyUICode.GDBonusGreenBallObjects8= [];
ByteZhenWenn.LobbyUICode.GDSunBonuseObjects1= [];
ByteZhenWenn.LobbyUICode.GDSunBonuseObjects2= [];
ByteZhenWenn.LobbyUICode.GDSunBonuseObjects3= [];
ByteZhenWenn.LobbyUICode.GDSunBonuseObjects4= [];
ByteZhenWenn.LobbyUICode.GDSunBonuseObjects5= [];
ByteZhenWenn.LobbyUICode.GDSunBonuseObjects6= [];
ByteZhenWenn.LobbyUICode.GDSunBonuseObjects7= [];
ByteZhenWenn.LobbyUICode.GDSunBonuseObjects8= [];
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierObjects1= [];
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierObjects2= [];
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierObjects3= [];
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierObjects4= [];
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierObjects5= [];
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierObjects6= [];
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierObjects7= [];
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierObjects8= [];
ByteZhenWenn.LobbyUICode.GDbonus_9595trailObjects1= [];
ByteZhenWenn.LobbyUICode.GDbonus_9595trailObjects2= [];
ByteZhenWenn.LobbyUICode.GDbonus_9595trailObjects3= [];
ByteZhenWenn.LobbyUICode.GDbonus_9595trailObjects4= [];
ByteZhenWenn.LobbyUICode.GDbonus_9595trailObjects5= [];
ByteZhenWenn.LobbyUICode.GDbonus_9595trailObjects6= [];
ByteZhenWenn.LobbyUICode.GDbonus_9595trailObjects7= [];
ByteZhenWenn.LobbyUICode.GDbonus_9595trailObjects8= [];
ByteZhenWenn.LobbyUICode.GDbonus_9595trail2Objects1= [];
ByteZhenWenn.LobbyUICode.GDbonus_9595trail2Objects2= [];
ByteZhenWenn.LobbyUICode.GDbonus_9595trail2Objects3= [];
ByteZhenWenn.LobbyUICode.GDbonus_9595trail2Objects4= [];
ByteZhenWenn.LobbyUICode.GDbonus_9595trail2Objects5= [];
ByteZhenWenn.LobbyUICode.GDbonus_9595trail2Objects6= [];
ByteZhenWenn.LobbyUICode.GDbonus_9595trail2Objects7= [];
ByteZhenWenn.LobbyUICode.GDbonus_9595trail2Objects8= [];
ByteZhenWenn.LobbyUICode.GDbonus_9595trail3Objects1= [];
ByteZhenWenn.LobbyUICode.GDbonus_9595trail3Objects2= [];
ByteZhenWenn.LobbyUICode.GDbonus_9595trail3Objects3= [];
ByteZhenWenn.LobbyUICode.GDbonus_9595trail3Objects4= [];
ByteZhenWenn.LobbyUICode.GDbonus_9595trail3Objects5= [];
ByteZhenWenn.LobbyUICode.GDbonus_9595trail3Objects6= [];
ByteZhenWenn.LobbyUICode.GDbonus_9595trail3Objects7= [];
ByteZhenWenn.LobbyUICode.GDbonus_9595trail3Objects8= [];
ByteZhenWenn.LobbyUICode.GDModalGoldObjects1= [];
ByteZhenWenn.LobbyUICode.GDModalGoldObjects2= [];
ByteZhenWenn.LobbyUICode.GDModalGoldObjects3= [];
ByteZhenWenn.LobbyUICode.GDModalGoldObjects4= [];
ByteZhenWenn.LobbyUICode.GDModalGoldObjects5= [];
ByteZhenWenn.LobbyUICode.GDModalGoldObjects6= [];
ByteZhenWenn.LobbyUICode.GDModalGoldObjects7= [];
ByteZhenWenn.LobbyUICode.GDModalGoldObjects8= [];
ByteZhenWenn.LobbyUICode.GDSensationalUIObjects1= [];
ByteZhenWenn.LobbyUICode.GDSensationalUIObjects2= [];
ByteZhenWenn.LobbyUICode.GDSensationalUIObjects3= [];
ByteZhenWenn.LobbyUICode.GDSensationalUIObjects4= [];
ByteZhenWenn.LobbyUICode.GDSensationalUIObjects5= [];
ByteZhenWenn.LobbyUICode.GDSensationalUIObjects6= [];
ByteZhenWenn.LobbyUICode.GDSensationalUIObjects7= [];
ByteZhenWenn.LobbyUICode.GDSensationalUIObjects8= [];
ByteZhenWenn.LobbyUICode.GDNewSprite2Objects1= [];
ByteZhenWenn.LobbyUICode.GDNewSprite2Objects2= [];
ByteZhenWenn.LobbyUICode.GDNewSprite2Objects3= [];
ByteZhenWenn.LobbyUICode.GDNewSprite2Objects4= [];
ByteZhenWenn.LobbyUICode.GDNewSprite2Objects5= [];
ByteZhenWenn.LobbyUICode.GDNewSprite2Objects6= [];
ByteZhenWenn.LobbyUICode.GDNewSprite2Objects7= [];
ByteZhenWenn.LobbyUICode.GDNewSprite2Objects8= [];
ByteZhenWenn.LobbyUICode.GDReceiveWinObjects1= [];
ByteZhenWenn.LobbyUICode.GDReceiveWinObjects2= [];
ByteZhenWenn.LobbyUICode.GDReceiveWinObjects3= [];
ByteZhenWenn.LobbyUICode.GDReceiveWinObjects4= [];
ByteZhenWenn.LobbyUICode.GDReceiveWinObjects5= [];
ByteZhenWenn.LobbyUICode.GDReceiveWinObjects6= [];
ByteZhenWenn.LobbyUICode.GDReceiveWinObjects7= [];
ByteZhenWenn.LobbyUICode.GDReceiveWinObjects8= [];
ByteZhenWenn.LobbyUICode.GDCoinPopUpObjects1= [];
ByteZhenWenn.LobbyUICode.GDCoinPopUpObjects2= [];
ByteZhenWenn.LobbyUICode.GDCoinPopUpObjects3= [];
ByteZhenWenn.LobbyUICode.GDCoinPopUpObjects4= [];
ByteZhenWenn.LobbyUICode.GDCoinPopUpObjects5= [];
ByteZhenWenn.LobbyUICode.GDCoinPopUpObjects6= [];
ByteZhenWenn.LobbyUICode.GDCoinPopUpObjects7= [];
ByteZhenWenn.LobbyUICode.GDCoinPopUpObjects8= [];
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierXObjects1= [];
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierXObjects2= [];
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierXObjects3= [];
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierXObjects4= [];
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierXObjects5= [];
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierXObjects6= [];
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierXObjects7= [];
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierXObjects8= [];


ByteZhenWenn.LobbyUICode.userFunc0xa9eab0 = function GDJSInlineCode(runtimeScene) {
"use strict";
/** DOC: Bind message listener once and set a scene flag instead of switching here */
if (!runtimeScene._messageBound) {
  runtimeScene._messageBound = true;

  window.addEventListener("message", (event) => {
    /** DOC: Same-origin guard */
    if (event.origin !== window.location.origin) return;
 
    const data = event.data || {};
    if (data.action === "match_start") {
        runtimeScene.getGame().getVariables().get("userbalance").setString(event.data.data);
        runtimeScene.getGame().getVariables().get("new_match_ready").setBoolean(true);
    }
    if (data.action === "refresh_balance") {
        runtimeScene.getGame().getVariables().get("userbalance").setString(event.data.data); 
    }
    if (data.action === "gameboard_reset") {
        runtimeScene.getGame().getVariables().get("gameboard_reset").setBoolean(true);
    }
    if (data.action === "chest_receive") {
      const chestdata = event.data.data;
      console.log(chestdata);
      window.ddZop(chestdata.chest_content.multiplier, chestdata.chest_content.prize_value, chestdata.chest_index, true, chestdata.all_results, chestdata);
    }
    if (data.action === "chest_allow_click") {
        runtimeScene.getGame().getVariables().get("opening_chest").setBoolean(false);
    }
  });

  let chestdatasimulate = {'bonus_multiplier' : 10};
  //window.ddZop(0.3, 0.2, 8, true, {}, chestdatasimulate);
 // setTimeout(() => {
  //window.ddZop(0.3, 0.2, 5, true, {}, chestdatasimulate);
 // }, 4000);
 // setTimeout(() => {
 // window.ddZop(0.3, 0.2, 3, true, {}, chestdatasimulate);
  //}, 5600);
}

};
ByteZhenWenn.LobbyUICode.eventsList0 = function(runtimeScene) {

{


ByteZhenWenn.LobbyUICode.userFunc0xa9eab0(runtimeScene);

}


};ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDPulseParticleObjects1Objects = Hashtable.newFrom({"PulseParticle": ByteZhenWenn.LobbyUICode.GDPulseParticleObjects1});
ByteZhenWenn.LobbyUICode.userFunc0xc99d48 = function GDJSInlineCode(runtimeScene) {
"use strict";
function _openedVar()   { return runtimeScene.getGame().getVariables().get("chests_opened"); }
function _revealVar()   { return runtimeScene.getGame().getVariables().get("chests_revealing"); }
_openedVar().getChild("0").setBoolean(false);
_revealVar().getChild("0").setBoolean(false);
_openedVar().getChild("1").setBoolean(false);
_revealVar().getChild("1").setBoolean(false);
_openedVar().getChild("2").setBoolean(false);
_revealVar().getChild("2").setBoolean(false);
_openedVar().getChild("3").setBoolean(false);
_revealVar().getChild("3").setBoolean(false);
_openedVar().getChild("4").setBoolean(false);
_revealVar().getChild("4").setBoolean(false);
_openedVar().getChild("5").setBoolean(false);
_revealVar().getChild("5").setBoolean(false);
_openedVar().getChild("6").setBoolean(false);
_revealVar().getChild("6").setBoolean(false);
_openedVar().getChild("7").setBoolean(false);
_revealVar().getChild("7").setBoolean(false);
_openedVar().getChild("8").setBoolean(false);
_revealVar().getChild("8").setBoolean(false);
window.parent.postMessage(
  { 
    type: 'match_start', 
    data: runtimeScene.getGame().getVariables().get("bet_amount").getAsNumber() 
  }, 
  window.location.origin
);

};
ByteZhenWenn.LobbyUICode.eventsList1 = function(runtimeScene, asyncObjectsList) {

{


ByteZhenWenn.LobbyUICode.userFunc0xc99d48(runtimeScene);

}


};ByteZhenWenn.LobbyUICode.asyncCallback14386956 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);

{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList1(runtimeScene, asyncObjectsList);} //End of subevents
ByteZhenWenn.LobbyUICode.localVariables.length = 0;
}
ByteZhenWenn.LobbyUICode.eventsList2 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = ByteZhenWenn.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(ByteZhenWenn.evtTools.runtimeScene.wait(0.18), (runtimeScene) => (ByteZhenWenn.LobbyUICode.asyncCallback14386956(runtimeScene, asyncObjectsList)));
}
}

}


};ByteZhenWenn.LobbyUICode.asyncCallback14387988 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
ByteZhenWenn.copyArray(runtimeScene.getObjects("Lock"), ByteZhenWenn.LobbyUICode.GDLockObjects2);
ByteZhenWenn.copyArray(asyncObjectsList.getObjects("SpinMainButton"), ByteZhenWenn.LobbyUICode.GDSpinMainButtonObjects2);

{runtimeScene.getGame().getVariables().getFromIndex(17).setBoolean(false);
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDSpinMainButtonObjects2.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDSpinMainButtonObjects2[i].getBehavior("Tween").addObjectScaleTween3("scale", (ByteZhenWenn.LobbyUICode.GDSpinMainButtonObjects2[i].getBehavior("Scale").getScale()) - 0.09, "linear", 0.15, false, true);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDLockObjects2.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDLockObjects2[i].getBehavior("Tween").addObjectPositionYTween2("rotlock", (ByteZhenWenn.LobbyUICode.GDLockObjects2[i].getPointY("")) + 100, "linear", 0.2, false);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDLockObjects2.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDLockObjects2[i].getBehavior("Tween").addObjectOpacityTween2("opalock", 0, "linear", 0.15, true);
}
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList2(runtimeScene, asyncObjectsList);} //End of subevents
ByteZhenWenn.LobbyUICode.localVariables.length = 0;
}
ByteZhenWenn.LobbyUICode.eventsList3 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new ByteZhenWenn.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
for (const obj of ByteZhenWenn.LobbyUICode.GDSpinMainButtonObjects1) asyncObjectsList.addObject("SpinMainButton", obj);
runtimeScene.getAsyncTasksManager().addTask(ByteZhenWenn.evtTools.runtimeScene.wait(0.18), (runtimeScene) => (ByteZhenWenn.LobbyUICode.asyncCallback14387988(runtimeScene, asyncObjectsList)));
}
}

}


};ByteZhenWenn.LobbyUICode.userFunc0xd0ddd8 = function GDJSInlineCode(runtimeScene) {
"use strict";
window.parent.postMessage(
  { 
    type: 'match_collect', 
    data: ''
  }, 
  window.location.origin
);

};
ByteZhenWenn.LobbyUICode.eventsList4 = function(runtimeScene, asyncObjectsList) {

{


ByteZhenWenn.LobbyUICode.userFunc0xd0ddd8(runtimeScene);

}


};ByteZhenWenn.LobbyUICode.asyncCallback14392932 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
{ByteZhenWenn.evtTools.camera.hideLayer(runtimeScene, "Bonus Screen");
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList4(runtimeScene, asyncObjectsList);} //End of subevents
ByteZhenWenn.LobbyUICode.localVariables.length = 0;
}
ByteZhenWenn.LobbyUICode.eventsList5 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new ByteZhenWenn.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(ByteZhenWenn.evtTools.runtimeScene.wait(3), (runtimeScene) => (ByteZhenWenn.LobbyUICode.asyncCallback14392932(runtimeScene, asyncObjectsList)));
}
}

}


};ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDChest1Objects3Objects = Hashtable.newFrom({"Chest1": ByteZhenWenn.LobbyUICode.GDChest1Objects3});
ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDChest2Objects3Objects = Hashtable.newFrom({"Chest2": ByteZhenWenn.LobbyUICode.GDChest2Objects3});
ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDChest3Objects3Objects = Hashtable.newFrom({"Chest3": ByteZhenWenn.LobbyUICode.GDChest3Objects3});
ByteZhenWenn.LobbyUICode.asyncCallback14395388 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
ByteZhenWenn.copyArray(asyncObjectsList.getObjects("Chest1"), ByteZhenWenn.LobbyUICode.GDChest1Objects3);

ByteZhenWenn.copyArray(asyncObjectsList.getObjects("Chest2"), ByteZhenWenn.LobbyUICode.GDChest2Objects3);

ByteZhenWenn.copyArray(asyncObjectsList.getObjects("Chest3"), ByteZhenWenn.LobbyUICode.GDChest3Objects3);

{ByteZhenWenn.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDChest1Objects3Objects, 120, 540, "");
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest1Objects3.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest1Objects3[i].getBehavior("Scale").setScale(0.25);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest1Objects3.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest1Objects3[i].getBehavior("Tween").addObjectPositionYTween2("chest1", 600, "linear", 0.1, false);
}
}{ByteZhenWenn.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDChest2Objects3Objects, 120, 540, "");
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest2Objects3.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest2Objects3[i].getBehavior("Scale").setScale(0.25);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest2Objects3.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest2Objects3[i].getBehavior("Tween").addObjectPositionYTween2("chest2", 754, "linear", 0.25, false);
}
}{ByteZhenWenn.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDChest3Objects3Objects, 120, 540, "");
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest3Objects3.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest3Objects3[i].getBehavior("Scale").setScale(0.25);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest3Objects3.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest3Objects3[i].getBehavior("Tween").addObjectPositionYTween2("chest3", 904, "linear", 0.4, false);
}
}ByteZhenWenn.LobbyUICode.localVariables.length = 0;
}
ByteZhenWenn.LobbyUICode.eventsList6 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new ByteZhenWenn.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
for (const obj of ByteZhenWenn.LobbyUICode.GDChest1Objects2) asyncObjectsList.addObject("Chest1", obj);
for (const obj of ByteZhenWenn.LobbyUICode.GDChest2Objects2) asyncObjectsList.addObject("Chest2", obj);
for (const obj of ByteZhenWenn.LobbyUICode.GDChest3Objects2) asyncObjectsList.addObject("Chest3", obj);
runtimeScene.getAsyncTasksManager().addTask(ByteZhenWenn.evtTools.runtimeScene.wait(0.01), (runtimeScene) => (ByteZhenWenn.LobbyUICode.asyncCallback14395388(runtimeScene, asyncObjectsList)));
}
}

}


};ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDChest4Objects3Objects = Hashtable.newFrom({"Chest4": ByteZhenWenn.LobbyUICode.GDChest4Objects3});
ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDChest5Objects3Objects = Hashtable.newFrom({"Chest5": ByteZhenWenn.LobbyUICode.GDChest5Objects3});
ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDChest6Objects3Objects = Hashtable.newFrom({"Chest6": ByteZhenWenn.LobbyUICode.GDChest6Objects3});
ByteZhenWenn.LobbyUICode.asyncCallback14398404 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
ByteZhenWenn.LobbyUICode.GDChest4Objects3.length = 0;

ByteZhenWenn.LobbyUICode.GDChest5Objects3.length = 0;

ByteZhenWenn.LobbyUICode.GDChest6Objects3.length = 0;

{ByteZhenWenn.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDChest4Objects3Objects, 304, 540, "");
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest4Objects3.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest4Objects3[i].getBehavior("Scale").setScale(0.25);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest4Objects3.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest4Objects3[i].getBehavior("Tween").addObjectPositionYTween2("chest4", 600, "linear", 0.1, false);
}
}{ByteZhenWenn.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDChest5Objects3Objects, 304, 540, "");
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest5Objects3.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest5Objects3[i].getBehavior("Scale").setScale(0.25);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest5Objects3.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest5Objects3[i].getBehavior("Tween").addObjectPositionYTween2("chest5", 754, "linear", 0.25, false);
}
}{ByteZhenWenn.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDChest6Objects3Objects, 304, 540, "");
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest6Objects3.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest6Objects3[i].getBehavior("Scale").setScale(0.25);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest6Objects3.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest6Objects3[i].getBehavior("Tween").addObjectPositionYTween2("chest6", 904, "linear", 0.4, false);
}
}ByteZhenWenn.LobbyUICode.localVariables.length = 0;
}
ByteZhenWenn.LobbyUICode.eventsList7 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new ByteZhenWenn.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(ByteZhenWenn.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (ByteZhenWenn.LobbyUICode.asyncCallback14398404(runtimeScene, asyncObjectsList)));
}
}

}


};ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDChest7Objects3Objects = Hashtable.newFrom({"Chest7": ByteZhenWenn.LobbyUICode.GDChest7Objects3});
ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDChest8Objects3Objects = Hashtable.newFrom({"Chest8": ByteZhenWenn.LobbyUICode.GDChest8Objects3});
ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDChest9Objects3Objects = Hashtable.newFrom({"Chest9": ByteZhenWenn.LobbyUICode.GDChest9Objects3});
ByteZhenWenn.LobbyUICode.asyncCallback14401004 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
ByteZhenWenn.LobbyUICode.GDChest7Objects3.length = 0;

ByteZhenWenn.LobbyUICode.GDChest8Objects3.length = 0;

ByteZhenWenn.LobbyUICode.GDChest9Objects3.length = 0;

{ByteZhenWenn.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDChest7Objects3Objects, 484, 540, "");
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest7Objects3.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest7Objects3[i].getBehavior("Scale").setScale(0.25);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest7Objects3.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest7Objects3[i].getBehavior("Tween").addObjectPositionYTween2("chest4", 600, "linear", 0.1, false);
}
}{ByteZhenWenn.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDChest8Objects3Objects, 484, 540, "");
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest8Objects3.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest8Objects3[i].getBehavior("Scale").setScale(0.25);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest8Objects3.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest8Objects3[i].getBehavior("Tween").addObjectPositionYTween2("chest5", 754, "linear", 0.25, false);
}
}{ByteZhenWenn.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDChest9Objects3Objects, 484, 540, "");
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest9Objects3.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest9Objects3[i].getBehavior("Scale").setScale(0.25);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest9Objects3.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest9Objects3[i].getBehavior("Tween").addObjectPositionYTween2("chest6", 904, "linear", 0.4, false);
}
}ByteZhenWenn.LobbyUICode.localVariables.length = 0;
}
ByteZhenWenn.LobbyUICode.eventsList8 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new ByteZhenWenn.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(ByteZhenWenn.evtTools.runtimeScene.wait(0.4), (runtimeScene) => (ByteZhenWenn.LobbyUICode.asyncCallback14401004(runtimeScene, asyncObjectsList)));
}
}

}


};ByteZhenWenn.LobbyUICode.eventsList9 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
ByteZhenWenn.copyArray(runtimeScene.getObjects("Chest1"), ByteZhenWenn.LobbyUICode.GDChest1Objects2);
ByteZhenWenn.copyArray(runtimeScene.getObjects("Chest2"), ByteZhenWenn.LobbyUICode.GDChest2Objects2);
ByteZhenWenn.copyArray(runtimeScene.getObjects("Chest3"), ByteZhenWenn.LobbyUICode.GDChest3Objects2);
ByteZhenWenn.copyArray(runtimeScene.getObjects("Chest4"), ByteZhenWenn.LobbyUICode.GDChest4Objects2);
ByteZhenWenn.copyArray(runtimeScene.getObjects("Chest5"), ByteZhenWenn.LobbyUICode.GDChest5Objects2);
ByteZhenWenn.copyArray(runtimeScene.getObjects("Chest6"), ByteZhenWenn.LobbyUICode.GDChest6Objects2);
ByteZhenWenn.copyArray(runtimeScene.getObjects("Chest7"), ByteZhenWenn.LobbyUICode.GDChest7Objects2);
ByteZhenWenn.copyArray(runtimeScene.getObjects("Chest8"), ByteZhenWenn.LobbyUICode.GDChest8Objects2);
ByteZhenWenn.copyArray(runtimeScene.getObjects("Chest9"), ByteZhenWenn.LobbyUICode.GDChest9Objects2);
{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest1Objects2.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest1Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest2Objects2.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest2Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest3Objects2.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest3Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest4Objects2.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest4Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest5Objects2.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest5Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest6Objects2.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest6Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest7Objects2.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest7Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest8Objects2.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest8Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest9Objects2.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest9Objects2[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList6(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList7(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{

{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList8(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
ByteZhenWenn.copyArray(runtimeScene.getObjects("ChestCollect"), ByteZhenWenn.LobbyUICode.GDChestCollectObjects1);
ByteZhenWenn.copyArray(runtimeScene.getObjects("NewSprite3"), ByteZhenWenn.LobbyUICode.GDNewSprite3Objects1);
ByteZhenWenn.copyArray(runtimeScene.getObjects("collect_text"), ByteZhenWenn.LobbyUICode.GDcollect_9595textObjects1);
{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDNewSprite3Objects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDNewSprite3Objects1[i].setColor("255;242;91");
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChestCollectObjects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChestCollectObjects1[i].getBehavior("Opacity").setOpacity(255);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDcollect_9595textObjects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDcollect_9595textObjects1[i].getBehavior("Opacity").setOpacity(255);
}
}}

}


};ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDChestExplosionObjects2Objects = Hashtable.newFrom({"ChestExplosion": ByteZhenWenn.LobbyUICode.GDChestExplosionObjects2});
ByteZhenWenn.LobbyUICode.userFunc0xf097a0 = function GDJSInlineCode(runtimeScene) {
"use strict";
window.parent.postMessage(
  { 
    type: 'chest_open', 
    data : 0
  }, 
  window.location.origin
);

};
ByteZhenWenn.LobbyUICode.eventsList10 = function(runtimeScene, asyncObjectsList) {

{


ByteZhenWenn.LobbyUICode.userFunc0xf097a0(runtimeScene);

}


};ByteZhenWenn.LobbyUICode.asyncCallback14406460 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
ByteZhenWenn.copyArray(asyncObjectsList.getObjects("Chest1"), ByteZhenWenn.LobbyUICode.GDChest1Objects4);

{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest1Objects4.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest1Objects4[i].getBehavior("Tween").addObjectOpacityTween2("chest1op", 0, "linear", 0.6, true);
}
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList10(runtimeScene, asyncObjectsList);} //End of subevents
ByteZhenWenn.LobbyUICode.localVariables.length = 0;
}
ByteZhenWenn.LobbyUICode.eventsList11 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = ByteZhenWenn.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
for (const obj of ByteZhenWenn.LobbyUICode.GDChest1Objects3) asyncObjectsList.addObject("Chest1", obj);
runtimeScene.getAsyncTasksManager().addTask(ByteZhenWenn.evtTools.runtimeScene.wait(0.10), (runtimeScene) => (ByteZhenWenn.LobbyUICode.asyncCallback14406460(runtimeScene, asyncObjectsList)));
}
}

}


};ByteZhenWenn.LobbyUICode.asyncCallback14406108 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
ByteZhenWenn.copyArray(asyncObjectsList.getObjects("Chest1"), ByteZhenWenn.LobbyUICode.GDChest1Objects3);

{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest1Objects3.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest1Objects3[i].getBehavior("Animation").setAnimationName("Open");
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest1Objects3.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest1Objects3[i].getBehavior("Scale").setScale(0.44);
}
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList11(runtimeScene, asyncObjectsList);} //End of subevents
ByteZhenWenn.LobbyUICode.localVariables.length = 0;
}
ByteZhenWenn.LobbyUICode.eventsList12 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new ByteZhenWenn.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
for (const obj of ByteZhenWenn.LobbyUICode.GDChest1Objects2) asyncObjectsList.addObject("Chest1", obj);
runtimeScene.getAsyncTasksManager().addTask(ByteZhenWenn.evtTools.runtimeScene.wait(0.10), (runtimeScene) => (ByteZhenWenn.LobbyUICode.asyncCallback14406108(runtimeScene, asyncObjectsList)));
}
}

}


};ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDChestExplosionObjects2Objects = Hashtable.newFrom({"ChestExplosion": ByteZhenWenn.LobbyUICode.GDChestExplosionObjects2});
ByteZhenWenn.LobbyUICode.userFunc0xf45550 = function GDJSInlineCode(runtimeScene) {
"use strict";
window.parent.postMessage(
  { 
    type: 'chest_open', 
    data : 1
  }, 
  window.location.origin
);

};
ByteZhenWenn.LobbyUICode.eventsList13 = function(runtimeScene, asyncObjectsList) {

{


ByteZhenWenn.LobbyUICode.userFunc0xf45550(runtimeScene);

}


};ByteZhenWenn.LobbyUICode.asyncCallback14408836 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
ByteZhenWenn.copyArray(asyncObjectsList.getObjects("Chest4"), ByteZhenWenn.LobbyUICode.GDChest4Objects4);

{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest4Objects4.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest4Objects4[i].getBehavior("Tween").addObjectOpacityTween2("chest4op", 0, "linear", 0.6, true);
}
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList13(runtimeScene, asyncObjectsList);} //End of subevents
ByteZhenWenn.LobbyUICode.localVariables.length = 0;
}
ByteZhenWenn.LobbyUICode.eventsList14 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = ByteZhenWenn.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
for (const obj of ByteZhenWenn.LobbyUICode.GDChest4Objects3) asyncObjectsList.addObject("Chest4", obj);
runtimeScene.getAsyncTasksManager().addTask(ByteZhenWenn.evtTools.runtimeScene.wait(0.10), (runtimeScene) => (ByteZhenWenn.LobbyUICode.asyncCallback14408836(runtimeScene, asyncObjectsList)));
}
}

}


};ByteZhenWenn.LobbyUICode.asyncCallback14408436 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
ByteZhenWenn.copyArray(asyncObjectsList.getObjects("Chest4"), ByteZhenWenn.LobbyUICode.GDChest4Objects3);

{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest4Objects3.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest4Objects3[i].getBehavior("Animation").setAnimationName("Open");
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest4Objects3.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest4Objects3[i].getBehavior("Scale").setScale(0.44);
}
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList14(runtimeScene, asyncObjectsList);} //End of subevents
ByteZhenWenn.LobbyUICode.localVariables.length = 0;
}
ByteZhenWenn.LobbyUICode.eventsList15 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new ByteZhenWenn.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
for (const obj of ByteZhenWenn.LobbyUICode.GDChest4Objects2) asyncObjectsList.addObject("Chest4", obj);
runtimeScene.getAsyncTasksManager().addTask(ByteZhenWenn.evtTools.runtimeScene.wait(0.10), (runtimeScene) => (ByteZhenWenn.LobbyUICode.asyncCallback14408436(runtimeScene, asyncObjectsList)));
}
}

}


};ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDChestExplosionObjects2Objects = Hashtable.newFrom({"ChestExplosion": ByteZhenWenn.LobbyUICode.GDChestExplosionObjects2});
ByteZhenWenn.LobbyUICode.userFunc0x6cdea8 = function GDJSInlineCode(runtimeScene) {
"use strict";
window.parent.postMessage(
  { 
    type: 'chest_open', 
    data : 2
  }, 
  window.location.origin
);

};
ByteZhenWenn.LobbyUICode.eventsList16 = function(runtimeScene, asyncObjectsList) {

{


ByteZhenWenn.LobbyUICode.userFunc0x6cdea8(runtimeScene);

}


};ByteZhenWenn.LobbyUICode.asyncCallback14411572 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
ByteZhenWenn.copyArray(asyncObjectsList.getObjects("Chest7"), ByteZhenWenn.LobbyUICode.GDChest7Objects4);

{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest7Objects4.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest7Objects4[i].getBehavior("Tween").addObjectOpacityTween2("chest7op", 0, "linear", 0.6, true);
}
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList16(runtimeScene, asyncObjectsList);} //End of subevents
ByteZhenWenn.LobbyUICode.localVariables.length = 0;
}
ByteZhenWenn.LobbyUICode.eventsList17 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = ByteZhenWenn.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
for (const obj of ByteZhenWenn.LobbyUICode.GDChest7Objects3) asyncObjectsList.addObject("Chest7", obj);
runtimeScene.getAsyncTasksManager().addTask(ByteZhenWenn.evtTools.runtimeScene.wait(0.10), (runtimeScene) => (ByteZhenWenn.LobbyUICode.asyncCallback14411572(runtimeScene, asyncObjectsList)));
}
}

}


};ByteZhenWenn.LobbyUICode.asyncCallback14411284 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
ByteZhenWenn.copyArray(asyncObjectsList.getObjects("Chest7"), ByteZhenWenn.LobbyUICode.GDChest7Objects3);

{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest7Objects3.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest7Objects3[i].getBehavior("Animation").setAnimationName("Open");
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest7Objects3.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest7Objects3[i].getBehavior("Scale").setScale(0.44);
}
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList17(runtimeScene, asyncObjectsList);} //End of subevents
ByteZhenWenn.LobbyUICode.localVariables.length = 0;
}
ByteZhenWenn.LobbyUICode.eventsList18 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new ByteZhenWenn.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
for (const obj of ByteZhenWenn.LobbyUICode.GDChest7Objects2) asyncObjectsList.addObject("Chest7", obj);
runtimeScene.getAsyncTasksManager().addTask(ByteZhenWenn.evtTools.runtimeScene.wait(0.10), (runtimeScene) => (ByteZhenWenn.LobbyUICode.asyncCallback14411284(runtimeScene, asyncObjectsList)));
}
}

}


};ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDChestExplosionObjects2Objects = Hashtable.newFrom({"ChestExplosion": ByteZhenWenn.LobbyUICode.GDChestExplosionObjects2});
ByteZhenWenn.LobbyUICode.userFunc0x1026b58 = function GDJSInlineCode(runtimeScene) {
"use strict";
window.parent.postMessage(
  { 
    type: 'chest_open', 
    data : 3
  }, 
  window.location.origin
);

};
ByteZhenWenn.LobbyUICode.eventsList19 = function(runtimeScene, asyncObjectsList) {

{


ByteZhenWenn.LobbyUICode.userFunc0x1026b58(runtimeScene);

}


};ByteZhenWenn.LobbyUICode.asyncCallback14414388 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
ByteZhenWenn.copyArray(asyncObjectsList.getObjects("Chest2"), ByteZhenWenn.LobbyUICode.GDChest2Objects4);

{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest2Objects4.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest2Objects4[i].getBehavior("Tween").addObjectOpacityTween2("chest2op", 0, "linear", 0.6, true);
}
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList19(runtimeScene, asyncObjectsList);} //End of subevents
ByteZhenWenn.LobbyUICode.localVariables.length = 0;
}
ByteZhenWenn.LobbyUICode.eventsList20 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = ByteZhenWenn.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
for (const obj of ByteZhenWenn.LobbyUICode.GDChest2Objects3) asyncObjectsList.addObject("Chest2", obj);
runtimeScene.getAsyncTasksManager().addTask(ByteZhenWenn.evtTools.runtimeScene.wait(0.10), (runtimeScene) => (ByteZhenWenn.LobbyUICode.asyncCallback14414388(runtimeScene, asyncObjectsList)));
}
}

}


};ByteZhenWenn.LobbyUICode.asyncCallback14413260 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
ByteZhenWenn.copyArray(asyncObjectsList.getObjects("Chest2"), ByteZhenWenn.LobbyUICode.GDChest2Objects3);

{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest2Objects3.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest2Objects3[i].getBehavior("Animation").setAnimationName("Open");
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest2Objects3.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest2Objects3[i].getBehavior("Scale").setScale(0.44);
}
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList20(runtimeScene, asyncObjectsList);} //End of subevents
ByteZhenWenn.LobbyUICode.localVariables.length = 0;
}
ByteZhenWenn.LobbyUICode.eventsList21 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new ByteZhenWenn.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
for (const obj of ByteZhenWenn.LobbyUICode.GDChest2Objects2) asyncObjectsList.addObject("Chest2", obj);
runtimeScene.getAsyncTasksManager().addTask(ByteZhenWenn.evtTools.runtimeScene.wait(0.10), (runtimeScene) => (ByteZhenWenn.LobbyUICode.asyncCallback14413260(runtimeScene, asyncObjectsList)));
}
}

}


};ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDChestExplosionObjects2Objects = Hashtable.newFrom({"ChestExplosion": ByteZhenWenn.LobbyUICode.GDChestExplosionObjects2});
ByteZhenWenn.LobbyUICode.userFunc0xfc6c50 = function GDJSInlineCode(runtimeScene) {
"use strict";
window.parent.postMessage(
  { 
    type: 'chest_open', 
    data : 4
  }, 
  window.location.origin
);

};
ByteZhenWenn.LobbyUICode.eventsList22 = function(runtimeScene, asyncObjectsList) {

{


ByteZhenWenn.LobbyUICode.userFunc0xfc6c50(runtimeScene);

}


};ByteZhenWenn.LobbyUICode.asyncCallback14417196 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
ByteZhenWenn.copyArray(asyncObjectsList.getObjects("Chest5"), ByteZhenWenn.LobbyUICode.GDChest5Objects4);

{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest5Objects4.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest5Objects4[i].getBehavior("Tween").addObjectOpacityTween2("chest5op", 0, "linear", 0.6, true);
}
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList22(runtimeScene, asyncObjectsList);} //End of subevents
ByteZhenWenn.LobbyUICode.localVariables.length = 0;
}
ByteZhenWenn.LobbyUICode.eventsList23 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = ByteZhenWenn.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
for (const obj of ByteZhenWenn.LobbyUICode.GDChest5Objects3) asyncObjectsList.addObject("Chest5", obj);
runtimeScene.getAsyncTasksManager().addTask(ByteZhenWenn.evtTools.runtimeScene.wait(0.10), (runtimeScene) => (ByteZhenWenn.LobbyUICode.asyncCallback14417196(runtimeScene, asyncObjectsList)));
}
}

}


};ByteZhenWenn.LobbyUICode.asyncCallback14416764 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
ByteZhenWenn.copyArray(asyncObjectsList.getObjects("Chest5"), ByteZhenWenn.LobbyUICode.GDChest5Objects3);

{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest5Objects3.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest5Objects3[i].getBehavior("Animation").setAnimationName("Open");
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest5Objects3.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest5Objects3[i].getBehavior("Scale").setScale(0.44);
}
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList23(runtimeScene, asyncObjectsList);} //End of subevents
ByteZhenWenn.LobbyUICode.localVariables.length = 0;
}
ByteZhenWenn.LobbyUICode.eventsList24 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new ByteZhenWenn.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
for (const obj of ByteZhenWenn.LobbyUICode.GDChest5Objects2) asyncObjectsList.addObject("Chest5", obj);
runtimeScene.getAsyncTasksManager().addTask(ByteZhenWenn.evtTools.runtimeScene.wait(0.10), (runtimeScene) => (ByteZhenWenn.LobbyUICode.asyncCallback14416764(runtimeScene, asyncObjectsList)));
}
}

}


};ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDChestExplosionObjects2Objects = Hashtable.newFrom({"ChestExplosion": ByteZhenWenn.LobbyUICode.GDChestExplosionObjects2});
ByteZhenWenn.LobbyUICode.userFunc0x1026c60 = function GDJSInlineCode(runtimeScene) {
"use strict";
window.parent.postMessage(
  { 
    type: 'chest_open', 
    data : 5
  }, 
  window.location.origin
);

};
ByteZhenWenn.LobbyUICode.eventsList25 = function(runtimeScene, asyncObjectsList) {

{


ByteZhenWenn.LobbyUICode.userFunc0x1026c60(runtimeScene);

}


};ByteZhenWenn.LobbyUICode.asyncCallback14419956 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
ByteZhenWenn.copyArray(asyncObjectsList.getObjects("Chest8"), ByteZhenWenn.LobbyUICode.GDChest8Objects4);

{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest8Objects4.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest8Objects4[i].getBehavior("Tween").addObjectOpacityTween2("chest8op", 0, "linear", 0.6, true);
}
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList25(runtimeScene, asyncObjectsList);} //End of subevents
ByteZhenWenn.LobbyUICode.localVariables.length = 0;
}
ByteZhenWenn.LobbyUICode.eventsList26 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = ByteZhenWenn.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
for (const obj of ByteZhenWenn.LobbyUICode.GDChest8Objects3) asyncObjectsList.addObject("Chest8", obj);
runtimeScene.getAsyncTasksManager().addTask(ByteZhenWenn.evtTools.runtimeScene.wait(0.10), (runtimeScene) => (ByteZhenWenn.LobbyUICode.asyncCallback14419956(runtimeScene, asyncObjectsList)));
}
}

}


};ByteZhenWenn.LobbyUICode.asyncCallback14419524 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
ByteZhenWenn.copyArray(asyncObjectsList.getObjects("Chest8"), ByteZhenWenn.LobbyUICode.GDChest8Objects3);

{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest8Objects3.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest8Objects3[i].getBehavior("Animation").setAnimationName("Open");
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest8Objects3.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest8Objects3[i].getBehavior("Scale").setScale(0.44);
}
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList26(runtimeScene, asyncObjectsList);} //End of subevents
ByteZhenWenn.LobbyUICode.localVariables.length = 0;
}
ByteZhenWenn.LobbyUICode.eventsList27 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new ByteZhenWenn.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
for (const obj of ByteZhenWenn.LobbyUICode.GDChest8Objects2) asyncObjectsList.addObject("Chest8", obj);
runtimeScene.getAsyncTasksManager().addTask(ByteZhenWenn.evtTools.runtimeScene.wait(0.10), (runtimeScene) => (ByteZhenWenn.LobbyUICode.asyncCallback14419524(runtimeScene, asyncObjectsList)));
}
}

}


};ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDChestExplosionObjects2Objects = Hashtable.newFrom({"ChestExplosion": ByteZhenWenn.LobbyUICode.GDChestExplosionObjects2});
ByteZhenWenn.LobbyUICode.userFunc0x7ad130 = function GDJSInlineCode(runtimeScene) {
"use strict";
window.parent.postMessage(
  { 
    type: 'chest_open', 
    data : 6
  }, 
  window.location.origin
);

};
ByteZhenWenn.LobbyUICode.eventsList28 = function(runtimeScene, asyncObjectsList) {

{


ByteZhenWenn.LobbyUICode.userFunc0x7ad130(runtimeScene);

}


};ByteZhenWenn.LobbyUICode.asyncCallback14423308 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
ByteZhenWenn.copyArray(asyncObjectsList.getObjects("Chest3"), ByteZhenWenn.LobbyUICode.GDChest3Objects4);

{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest3Objects4.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest3Objects4[i].getBehavior("Tween").addObjectOpacityTween2("chest3op", 0, "linear", 0.6, true);
}
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList28(runtimeScene, asyncObjectsList);} //End of subevents
ByteZhenWenn.LobbyUICode.localVariables.length = 0;
}
ByteZhenWenn.LobbyUICode.eventsList29 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = ByteZhenWenn.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
for (const obj of ByteZhenWenn.LobbyUICode.GDChest3Objects3) asyncObjectsList.addObject("Chest3", obj);
runtimeScene.getAsyncTasksManager().addTask(ByteZhenWenn.evtTools.runtimeScene.wait(0.10), (runtimeScene) => (ByteZhenWenn.LobbyUICode.asyncCallback14423308(runtimeScene, asyncObjectsList)));
}
}

}


};ByteZhenWenn.LobbyUICode.asyncCallback14422604 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
ByteZhenWenn.copyArray(asyncObjectsList.getObjects("Chest3"), ByteZhenWenn.LobbyUICode.GDChest3Objects3);

{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest3Objects3.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest3Objects3[i].getBehavior("Animation").setAnimationName("Open");
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest3Objects3.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest3Objects3[i].getBehavior("Scale").setScale(0.44);
}
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList29(runtimeScene, asyncObjectsList);} //End of subevents
ByteZhenWenn.LobbyUICode.localVariables.length = 0;
}
ByteZhenWenn.LobbyUICode.eventsList30 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new ByteZhenWenn.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
for (const obj of ByteZhenWenn.LobbyUICode.GDChest3Objects2) asyncObjectsList.addObject("Chest3", obj);
runtimeScene.getAsyncTasksManager().addTask(ByteZhenWenn.evtTools.runtimeScene.wait(0.10), (runtimeScene) => (ByteZhenWenn.LobbyUICode.asyncCallback14422604(runtimeScene, asyncObjectsList)));
}
}

}


};ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDChestExplosionObjects2Objects = Hashtable.newFrom({"ChestExplosion": ByteZhenWenn.LobbyUICode.GDChestExplosionObjects2});
ByteZhenWenn.LobbyUICode.userFunc0x921708 = function GDJSInlineCode(runtimeScene) {
"use strict";
window.parent.postMessage(
  { 
    type: 'chest_open', 
    data : 7
  }, 
  window.location.origin
);

};
ByteZhenWenn.LobbyUICode.eventsList31 = function(runtimeScene, asyncObjectsList) {

{


ByteZhenWenn.LobbyUICode.userFunc0x921708(runtimeScene);

}


};ByteZhenWenn.LobbyUICode.asyncCallback14425300 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
ByteZhenWenn.copyArray(asyncObjectsList.getObjects("Chest6"), ByteZhenWenn.LobbyUICode.GDChest6Objects4);

{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest6Objects4.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest6Objects4[i].getBehavior("Tween").addObjectOpacityTween2("chest6op", 0, "linear", 0.6, true);
}
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList31(runtimeScene, asyncObjectsList);} //End of subevents
ByteZhenWenn.LobbyUICode.localVariables.length = 0;
}
ByteZhenWenn.LobbyUICode.eventsList32 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = ByteZhenWenn.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
for (const obj of ByteZhenWenn.LobbyUICode.GDChest6Objects3) asyncObjectsList.addObject("Chest6", obj);
runtimeScene.getAsyncTasksManager().addTask(ByteZhenWenn.evtTools.runtimeScene.wait(0.10), (runtimeScene) => (ByteZhenWenn.LobbyUICode.asyncCallback14425300(runtimeScene, asyncObjectsList)));
}
}

}


};ByteZhenWenn.LobbyUICode.asyncCallback14425012 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
ByteZhenWenn.copyArray(asyncObjectsList.getObjects("Chest6"), ByteZhenWenn.LobbyUICode.GDChest6Objects3);

{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest6Objects3.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest6Objects3[i].getBehavior("Animation").setAnimationName("Open");
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest6Objects3.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest6Objects3[i].getBehavior("Scale").setScale(0.44);
}
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList32(runtimeScene, asyncObjectsList);} //End of subevents
ByteZhenWenn.LobbyUICode.localVariables.length = 0;
}
ByteZhenWenn.LobbyUICode.eventsList33 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new ByteZhenWenn.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
for (const obj of ByteZhenWenn.LobbyUICode.GDChest6Objects2) asyncObjectsList.addObject("Chest6", obj);
runtimeScene.getAsyncTasksManager().addTask(ByteZhenWenn.evtTools.runtimeScene.wait(0.10), (runtimeScene) => (ByteZhenWenn.LobbyUICode.asyncCallback14425012(runtimeScene, asyncObjectsList)));
}
}

}


};ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDChestExplosionObjects1Objects = Hashtable.newFrom({"ChestExplosion": ByteZhenWenn.LobbyUICode.GDChestExplosionObjects1});
ByteZhenWenn.LobbyUICode.userFunc0xcf6dd8 = function GDJSInlineCode(runtimeScene) {
"use strict";
window.parent.postMessage(
  { 
    type: 'chest_open', 
    data : 8
  }, 
  window.location.origin
);

};
ByteZhenWenn.LobbyUICode.eventsList34 = function(runtimeScene, asyncObjectsList) {

{


ByteZhenWenn.LobbyUICode.userFunc0xcf6dd8(runtimeScene);

}


};ByteZhenWenn.LobbyUICode.asyncCallback14428060 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
ByteZhenWenn.copyArray(asyncObjectsList.getObjects("Chest9"), ByteZhenWenn.LobbyUICode.GDChest9Objects3);

{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest9Objects3.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest9Objects3[i].getBehavior("Tween").addObjectOpacityTween2("chest9op", 0, "linear", 0.6, true);
}
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList34(runtimeScene, asyncObjectsList);} //End of subevents
ByteZhenWenn.LobbyUICode.localVariables.length = 0;
}
ByteZhenWenn.LobbyUICode.eventsList35 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = ByteZhenWenn.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
for (const obj of ByteZhenWenn.LobbyUICode.GDChest9Objects2) asyncObjectsList.addObject("Chest9", obj);
runtimeScene.getAsyncTasksManager().addTask(ByteZhenWenn.evtTools.runtimeScene.wait(0.10), (runtimeScene) => (ByteZhenWenn.LobbyUICode.asyncCallback14428060(runtimeScene, asyncObjectsList)));
}
}

}


};ByteZhenWenn.LobbyUICode.asyncCallback14427772 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
ByteZhenWenn.copyArray(asyncObjectsList.getObjects("Chest9"), ByteZhenWenn.LobbyUICode.GDChest9Objects2);

{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest9Objects2.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest9Objects2[i].getBehavior("Animation").setAnimationName("Open");
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest9Objects2.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest9Objects2[i].getBehavior("Scale").setScale(0.44);
}
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList35(runtimeScene, asyncObjectsList);} //End of subevents
ByteZhenWenn.LobbyUICode.localVariables.length = 0;
}
ByteZhenWenn.LobbyUICode.eventsList36 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new ByteZhenWenn.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
for (const obj of ByteZhenWenn.LobbyUICode.GDChest9Objects1) asyncObjectsList.addObject("Chest9", obj);
runtimeScene.getAsyncTasksManager().addTask(ByteZhenWenn.evtTools.runtimeScene.wait(0.10), (runtimeScene) => (ByteZhenWenn.LobbyUICode.asyncCallback14427772(runtimeScene, asyncObjectsList)));
}
}

}


};ByteZhenWenn.LobbyUICode.eventsList37 = function(runtimeScene) {

{

ByteZhenWenn.copyArray(runtimeScene.getObjects("Chest1"), ByteZhenWenn.LobbyUICode.GDChest1Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = ByteZhenWenn.LobbyUICode.GDChest1Objects2.length;i<l;++i) {
    if ( ByteZhenWenn.LobbyUICode.GDChest1Objects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        ByteZhenWenn.LobbyUICode.GDChest1Objects2[k] = ByteZhenWenn.LobbyUICode.GDChest1Objects2[i];
        ++k;
    }
}
ByteZhenWenn.LobbyUICode.GDChest1Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getGame().getVariables().getFromIndex(10).getAsBoolean();
}
}
if (isConditionTrue_0) {
/* Reuse ByteZhenWenn.LobbyUICode.GDChest1Objects2 */
ByteZhenWenn.LobbyUICode.GDChestExplosionObjects2.length = 0;

{runtimeScene.getGame().getVariables().getFromIndex(10).setBoolean(true);
}{ByteZhenWenn.evtTools.sound.playSound(runtimeScene, "Zhelong/assets-ZhaoXing_sq4yz1arce.mp3", false, 100, 1.5);
}{ByteZhenWenn.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDChestExplosionObjects2Objects, (( ByteZhenWenn.LobbyUICode.GDChest1Objects2.length === 0 ) ? 0 :ByteZhenWenn.LobbyUICode.GDChest1Objects2[0].getPointX("")) + 50, (( ByteZhenWenn.LobbyUICode.GDChest1Objects2.length === 0 ) ? 0 :ByteZhenWenn.LobbyUICode.GDChest1Objects2[0].getPointY("")) + 50, "");
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList12(runtimeScene);} //End of subevents
}

}


{

ByteZhenWenn.copyArray(runtimeScene.getObjects("Chest4"), ByteZhenWenn.LobbyUICode.GDChest4Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = ByteZhenWenn.LobbyUICode.GDChest4Objects2.length;i<l;++i) {
    if ( ByteZhenWenn.LobbyUICode.GDChest4Objects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        ByteZhenWenn.LobbyUICode.GDChest4Objects2[k] = ByteZhenWenn.LobbyUICode.GDChest4Objects2[i];
        ++k;
    }
}
ByteZhenWenn.LobbyUICode.GDChest4Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getGame().getVariables().getFromIndex(10).getAsBoolean();
}
}
if (isConditionTrue_0) {
/* Reuse ByteZhenWenn.LobbyUICode.GDChest4Objects2 */
ByteZhenWenn.LobbyUICode.GDChestExplosionObjects2.length = 0;

{runtimeScene.getGame().getVariables().getFromIndex(10).setBoolean(true);
}{ByteZhenWenn.evtTools.sound.playSound(runtimeScene, "Zhelong/assets-ZhaoXing_sq4yz1arce.mp3", false, 100, 1.5);
}{ByteZhenWenn.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDChestExplosionObjects2Objects, (( ByteZhenWenn.LobbyUICode.GDChest4Objects2.length === 0 ) ? 0 :ByteZhenWenn.LobbyUICode.GDChest4Objects2[0].getPointX("")) + 50, (( ByteZhenWenn.LobbyUICode.GDChest4Objects2.length === 0 ) ? 0 :ByteZhenWenn.LobbyUICode.GDChest4Objects2[0].getPointY("")) + 50, "");
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList15(runtimeScene);} //End of subevents
}

}


{

ByteZhenWenn.copyArray(runtimeScene.getObjects("Chest7"), ByteZhenWenn.LobbyUICode.GDChest7Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = ByteZhenWenn.LobbyUICode.GDChest7Objects2.length;i<l;++i) {
    if ( ByteZhenWenn.LobbyUICode.GDChest7Objects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        ByteZhenWenn.LobbyUICode.GDChest7Objects2[k] = ByteZhenWenn.LobbyUICode.GDChest7Objects2[i];
        ++k;
    }
}
ByteZhenWenn.LobbyUICode.GDChest7Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getGame().getVariables().getFromIndex(10).getAsBoolean();
}
}
if (isConditionTrue_0) {
/* Reuse ByteZhenWenn.LobbyUICode.GDChest7Objects2 */
ByteZhenWenn.LobbyUICode.GDChestExplosionObjects2.length = 0;

{runtimeScene.getGame().getVariables().getFromIndex(10).setBoolean(true);
}{ByteZhenWenn.evtTools.sound.playSound(runtimeScene, "Zhelong/assets-ZhaoXing_sq4yz1arce.mp3", false, 100, 1.5);
}{ByteZhenWenn.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDChestExplosionObjects2Objects, (( ByteZhenWenn.LobbyUICode.GDChest7Objects2.length === 0 ) ? 0 :ByteZhenWenn.LobbyUICode.GDChest7Objects2[0].getPointX("")) + 50, (( ByteZhenWenn.LobbyUICode.GDChest7Objects2.length === 0 ) ? 0 :ByteZhenWenn.LobbyUICode.GDChest7Objects2[0].getPointY("")) + 50, "");
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList18(runtimeScene);} //End of subevents
}

}


{

ByteZhenWenn.copyArray(runtimeScene.getObjects("Chest2"), ByteZhenWenn.LobbyUICode.GDChest2Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = ByteZhenWenn.LobbyUICode.GDChest2Objects2.length;i<l;++i) {
    if ( ByteZhenWenn.LobbyUICode.GDChest2Objects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        ByteZhenWenn.LobbyUICode.GDChest2Objects2[k] = ByteZhenWenn.LobbyUICode.GDChest2Objects2[i];
        ++k;
    }
}
ByteZhenWenn.LobbyUICode.GDChest2Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getGame().getVariables().getFromIndex(10).getAsBoolean();
}
}
if (isConditionTrue_0) {
/* Reuse ByteZhenWenn.LobbyUICode.GDChest2Objects2 */
ByteZhenWenn.LobbyUICode.GDChestExplosionObjects2.length = 0;

{runtimeScene.getGame().getVariables().getFromIndex(10).setBoolean(true);
}{ByteZhenWenn.evtTools.sound.playSound(runtimeScene, "Zhelong/assets-ZhaoXing_sq4yz1arce.mp3", false, 100, 1.5);
}{ByteZhenWenn.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDChestExplosionObjects2Objects, (( ByteZhenWenn.LobbyUICode.GDChest2Objects2.length === 0 ) ? 0 :ByteZhenWenn.LobbyUICode.GDChest2Objects2[0].getPointX("")) + 50, (( ByteZhenWenn.LobbyUICode.GDChest2Objects2.length === 0 ) ? 0 :ByteZhenWenn.LobbyUICode.GDChest2Objects2[0].getPointY("")) + 50, "");
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList21(runtimeScene);} //End of subevents
}

}


{

ByteZhenWenn.copyArray(runtimeScene.getObjects("Chest5"), ByteZhenWenn.LobbyUICode.GDChest5Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = ByteZhenWenn.LobbyUICode.GDChest5Objects2.length;i<l;++i) {
    if ( ByteZhenWenn.LobbyUICode.GDChest5Objects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        ByteZhenWenn.LobbyUICode.GDChest5Objects2[k] = ByteZhenWenn.LobbyUICode.GDChest5Objects2[i];
        ++k;
    }
}
ByteZhenWenn.LobbyUICode.GDChest5Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getGame().getVariables().getFromIndex(10).getAsBoolean();
}
}
if (isConditionTrue_0) {
/* Reuse ByteZhenWenn.LobbyUICode.GDChest5Objects2 */
ByteZhenWenn.LobbyUICode.GDChestExplosionObjects2.length = 0;

{runtimeScene.getGame().getVariables().getFromIndex(10).setBoolean(true);
}{ByteZhenWenn.evtTools.sound.playSound(runtimeScene, "Zhelong/assets-ZhaoXing_sq4yz1arce.mp3", false, 100, 1.5);
}{ByteZhenWenn.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDChestExplosionObjects2Objects, (( ByteZhenWenn.LobbyUICode.GDChest5Objects2.length === 0 ) ? 0 :ByteZhenWenn.LobbyUICode.GDChest5Objects2[0].getPointX("")) + 50, (( ByteZhenWenn.LobbyUICode.GDChest5Objects2.length === 0 ) ? 0 :ByteZhenWenn.LobbyUICode.GDChest5Objects2[0].getPointY("")) + 50, "");
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList24(runtimeScene);} //End of subevents
}

}


{

ByteZhenWenn.copyArray(runtimeScene.getObjects("Chest8"), ByteZhenWenn.LobbyUICode.GDChest8Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = ByteZhenWenn.LobbyUICode.GDChest8Objects2.length;i<l;++i) {
    if ( ByteZhenWenn.LobbyUICode.GDChest8Objects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        ByteZhenWenn.LobbyUICode.GDChest8Objects2[k] = ByteZhenWenn.LobbyUICode.GDChest8Objects2[i];
        ++k;
    }
}
ByteZhenWenn.LobbyUICode.GDChest8Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getGame().getVariables().getFromIndex(10).getAsBoolean();
}
}
if (isConditionTrue_0) {
/* Reuse ByteZhenWenn.LobbyUICode.GDChest8Objects2 */
ByteZhenWenn.LobbyUICode.GDChestExplosionObjects2.length = 0;

{runtimeScene.getGame().getVariables().getFromIndex(10).setBoolean(true);
}{ByteZhenWenn.evtTools.sound.playSound(runtimeScene, "Zhelong/assets-ZhaoXing_sq4yz1arce.mp3", false, 100, 1.5);
}{ByteZhenWenn.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDChestExplosionObjects2Objects, (( ByteZhenWenn.LobbyUICode.GDChest8Objects2.length === 0 ) ? 0 :ByteZhenWenn.LobbyUICode.GDChest8Objects2[0].getPointX("")) + 50, (( ByteZhenWenn.LobbyUICode.GDChest8Objects2.length === 0 ) ? 0 :ByteZhenWenn.LobbyUICode.GDChest8Objects2[0].getPointY("")) + 50, "");
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList27(runtimeScene);} //End of subevents
}

}


{

ByteZhenWenn.copyArray(runtimeScene.getObjects("Chest3"), ByteZhenWenn.LobbyUICode.GDChest3Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = ByteZhenWenn.LobbyUICode.GDChest3Objects2.length;i<l;++i) {
    if ( ByteZhenWenn.LobbyUICode.GDChest3Objects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        ByteZhenWenn.LobbyUICode.GDChest3Objects2[k] = ByteZhenWenn.LobbyUICode.GDChest3Objects2[i];
        ++k;
    }
}
ByteZhenWenn.LobbyUICode.GDChest3Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getGame().getVariables().getFromIndex(10).getAsBoolean();
}
}
if (isConditionTrue_0) {
/* Reuse ByteZhenWenn.LobbyUICode.GDChest3Objects2 */
ByteZhenWenn.LobbyUICode.GDChestExplosionObjects2.length = 0;

{runtimeScene.getGame().getVariables().getFromIndex(10).setBoolean(true);
}{ByteZhenWenn.evtTools.sound.playSound(runtimeScene, "Zhelong/assets-ZhaoXing_sq4yz1arce.mp3", false, 100, 1.5);
}{ByteZhenWenn.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDChestExplosionObjects2Objects, (( ByteZhenWenn.LobbyUICode.GDChest3Objects2.length === 0 ) ? 0 :ByteZhenWenn.LobbyUICode.GDChest3Objects2[0].getPointX("")) + 50, (( ByteZhenWenn.LobbyUICode.GDChest3Objects2.length === 0 ) ? 0 :ByteZhenWenn.LobbyUICode.GDChest3Objects2[0].getPointY("")) + 50, "");
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList30(runtimeScene);} //End of subevents
}

}


{

ByteZhenWenn.copyArray(runtimeScene.getObjects("Chest6"), ByteZhenWenn.LobbyUICode.GDChest6Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = ByteZhenWenn.LobbyUICode.GDChest6Objects2.length;i<l;++i) {
    if ( ByteZhenWenn.LobbyUICode.GDChest6Objects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        ByteZhenWenn.LobbyUICode.GDChest6Objects2[k] = ByteZhenWenn.LobbyUICode.GDChest6Objects2[i];
        ++k;
    }
}
ByteZhenWenn.LobbyUICode.GDChest6Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getGame().getVariables().getFromIndex(10).getAsBoolean();
}
}
if (isConditionTrue_0) {
/* Reuse ByteZhenWenn.LobbyUICode.GDChest6Objects2 */
ByteZhenWenn.LobbyUICode.GDChestExplosionObjects2.length = 0;

{runtimeScene.getGame().getVariables().getFromIndex(10).setBoolean(true);
}{ByteZhenWenn.evtTools.sound.playSound(runtimeScene, "Zhelong/assets-ZhaoXing_sq4yz1arce.mp3", false, 100, 1.5);
}{ByteZhenWenn.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDChestExplosionObjects2Objects, (( ByteZhenWenn.LobbyUICode.GDChest6Objects2.length === 0 ) ? 0 :ByteZhenWenn.LobbyUICode.GDChest6Objects2[0].getPointX("")) + 50, (( ByteZhenWenn.LobbyUICode.GDChest6Objects2.length === 0 ) ? 0 :ByteZhenWenn.LobbyUICode.GDChest6Objects2[0].getPointY("")) + 50, "");
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList33(runtimeScene);} //End of subevents
}

}


{

ByteZhenWenn.copyArray(runtimeScene.getObjects("Chest9"), ByteZhenWenn.LobbyUICode.GDChest9Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = ByteZhenWenn.LobbyUICode.GDChest9Objects1.length;i<l;++i) {
    if ( ByteZhenWenn.LobbyUICode.GDChest9Objects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        ByteZhenWenn.LobbyUICode.GDChest9Objects1[k] = ByteZhenWenn.LobbyUICode.GDChest9Objects1[i];
        ++k;
    }
}
ByteZhenWenn.LobbyUICode.GDChest9Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getGame().getVariables().getFromIndex(10).getAsBoolean();
}
}
if (isConditionTrue_0) {
/* Reuse ByteZhenWenn.LobbyUICode.GDChest9Objects1 */
ByteZhenWenn.LobbyUICode.GDChestExplosionObjects1.length = 0;

{runtimeScene.getGame().getVariables().getFromIndex(10).setBoolean(true);
}{ByteZhenWenn.evtTools.sound.playSound(runtimeScene, "Zhelong/assets-ZhaoXing_sq4yz1arce.mp3", false, 100, 1.5);
}{ByteZhenWenn.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDChestExplosionObjects1Objects, (( ByteZhenWenn.LobbyUICode.GDChest9Objects1.length === 0 ) ? 0 :ByteZhenWenn.LobbyUICode.GDChest9Objects1[0].getPointX("")) + 50, (( ByteZhenWenn.LobbyUICode.GDChest9Objects1.length === 0 ) ? 0 :ByteZhenWenn.LobbyUICode.GDChest9Objects1[0].getPointY("")) + 50, "");
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList36(runtimeScene);} //End of subevents
}

}


};ByteZhenWenn.LobbyUICode.eventsList38 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber() == 100.00);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(250.00);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber() == 50.00);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(100.00);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber() == 40.00);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(50.00);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber() == 20.00);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(40.00);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber() == 16.00);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(20.00);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber() == 8.00);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(16.00);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber() == 4.00);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(8.00);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber() == 2.00);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(4.00);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber() == 1.20);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(2.00);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber() == 0.80);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(1.20);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber() == 0.40);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(0.80);
}}

}


};ByteZhenWenn.LobbyUICode.eventsList39 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber() == 0.80);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(0.40);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber() == 1.20);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(0.80);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber() == 2.00);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(1.20);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber() == 4.00);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(2.00);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber() == 8.00);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(4.00);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber() == 16.00);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(8.00);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber() == 20.00);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(16.00);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber() == 40.00);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(20.00);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber() == 50.00);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(40.00);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber() == 100.00);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(50.00);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber() == 250.00);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(100.00);
}}

}


};ByteZhenWenn.LobbyUICode.eventsList40 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(14).getAsNumber() == 0);
}
if (isConditionTrue_0) {
/* Reuse ByteZhenWenn.LobbyUICode.GDui_9595soundObjects2 */
ByteZhenWenn.copyArray(runtimeScene.getObjects("ui_sound_txt"), ByteZhenWenn.LobbyUICode.GDui_9595sound_9595txtObjects2);
{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDui_9595sound_9595txtObjects2.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDui_9595sound_9595txtObjects2[i].getBehavior("Opacity").setOpacity(255);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDui_9595soundObjects2.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDui_9595soundObjects2[i].getBehavior("Opacity").setOpacity(255);
}
}{runtimeScene.getGame().getVariables().getFromIndex(14).setNumber(77);
}{runtimeScene.getGame().getVariables().getFromIndex(15).setNumber(10);
}{runtimeScene.getGame().getVariables().getFromIndex(16).setBoolean(true);
}}

}


};ByteZhenWenn.LobbyUICode.eventsList41 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(14).getAsNumber() == 77);
}
if (isConditionTrue_0) {
/* Reuse ByteZhenWenn.LobbyUICode.GDui_9595soundObjects2 */
ByteZhenWenn.copyArray(runtimeScene.getObjects("ui_sound_txt"), ByteZhenWenn.LobbyUICode.GDui_9595sound_9595txtObjects2);
{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDui_9595sound_9595txtObjects2.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDui_9595sound_9595txtObjects2[i].getBehavior("Opacity").setOpacity(20);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDui_9595soundObjects2.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDui_9595soundObjects2[i].getBehavior("Opacity").setOpacity(20);
}
}{runtimeScene.getGame().getVariables().getFromIndex(14).setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(15).setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(16).setBoolean(true);
}}

}


};ByteZhenWenn.LobbyUICode.eventsList42 = function(runtimeScene) {

{

ByteZhenWenn.copyArray(runtimeScene.getObjects("Plus"), ByteZhenWenn.LobbyUICode.GDPlusObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = ByteZhenWenn.LobbyUICode.GDPlusObjects2.length;i<l;++i) {
    if ( ByteZhenWenn.LobbyUICode.GDPlusObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        ByteZhenWenn.LobbyUICode.GDPlusObjects2[k] = ByteZhenWenn.LobbyUICode.GDPlusObjects2[i];
        ++k;
    }
}
ByteZhenWenn.LobbyUICode.GDPlusObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getGame().getVariables().getFromIndex(1).getAsBoolean();
}
}
if (isConditionTrue_0) {

{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList38(runtimeScene);} //End of subevents
}

}


{

ByteZhenWenn.copyArray(runtimeScene.getObjects("Minus"), ByteZhenWenn.LobbyUICode.GDMinusObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = ByteZhenWenn.LobbyUICode.GDMinusObjects2.length;i<l;++i) {
    if ( ByteZhenWenn.LobbyUICode.GDMinusObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        ByteZhenWenn.LobbyUICode.GDMinusObjects2[k] = ByteZhenWenn.LobbyUICode.GDMinusObjects2[i];
        ++k;
    }
}
ByteZhenWenn.LobbyUICode.GDMinusObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getGame().getVariables().getFromIndex(1).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber() > 0.40);
}
}
}
if (isConditionTrue_0) {

{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList39(runtimeScene);} //End of subevents
}

}


{

ByteZhenWenn.copyArray(runtimeScene.getObjects("ui_sound"), ByteZhenWenn.LobbyUICode.GDui_9595soundObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = ByteZhenWenn.LobbyUICode.GDui_9595soundObjects2.length;i<l;++i) {
    if ( ByteZhenWenn.LobbyUICode.GDui_9595soundObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        ByteZhenWenn.LobbyUICode.GDui_9595soundObjects2[k] = ByteZhenWenn.LobbyUICode.GDui_9595soundObjects2[i];
        ++k;
    }
}
ByteZhenWenn.LobbyUICode.GDui_9595soundObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList40(runtimeScene);} //End of subevents
}

}


{

ByteZhenWenn.copyArray(runtimeScene.getObjects("ui_sound"), ByteZhenWenn.LobbyUICode.GDui_9595soundObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = ByteZhenWenn.LobbyUICode.GDui_9595soundObjects2.length;i<l;++i) {
    if ( ByteZhenWenn.LobbyUICode.GDui_9595soundObjects2[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        ByteZhenWenn.LobbyUICode.GDui_9595soundObjects2[k] = ByteZhenWenn.LobbyUICode.GDui_9595soundObjects2[i];
        ++k;
    }
}
ByteZhenWenn.LobbyUICode.GDui_9595soundObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList41(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(16).getAsBoolean();
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(16).setBoolean(false);
}{ByteZhenWenn.evtTools.sound.setMusicOnChannelVolume(runtimeScene, 10, runtimeScene.getGame().getVariables().getFromIndex(14).getAsNumber());
}}

}


};ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDNewLightObjects2Objects = Hashtable.newFrom({"NewLight": ByteZhenWenn.LobbyUICode.GDNewLightObjects2});
ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDMultiplierParticle2XObjects2Objects = Hashtable.newFrom({"MultiplierParticle2X": ByteZhenWenn.LobbyUICode.GDMultiplierParticle2XObjects2});
ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDMultiplierParticle5XObjects3Objects = Hashtable.newFrom({"MultiplierParticle5X": ByteZhenWenn.LobbyUICode.GDMultiplierParticle5XObjects3});
ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDMultiplierParticle10XObjects4Objects = Hashtable.newFrom({"MultiplierParticle10X": ByteZhenWenn.LobbyUICode.GDMultiplierParticle10XObjects4});
ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDMultiplierParticle3XObjects5Objects = Hashtable.newFrom({"MultiplierParticle3X": ByteZhenWenn.LobbyUICode.GDMultiplierParticle3XObjects5});
ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDSunBonuseObjects6Objects = Hashtable.newFrom({"SunBonuse": ByteZhenWenn.LobbyUICode.GDSunBonuseObjects6});
ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDBonuseMultiplierObjects7Objects = Hashtable.newFrom({"BonuseMultiplier": ByteZhenWenn.LobbyUICode.GDBonuseMultiplierObjects7});
ByteZhenWenn.LobbyUICode.asyncCallback14463404 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
{ByteZhenWenn.evtTools.sound.playSound(runtimeScene, "Zhelong/assets-ZhaoTing_387edjyj02.mp3", false, 80, 1);
}ByteZhenWenn.LobbyUICode.localVariables.length = 0;
}
ByteZhenWenn.LobbyUICode.eventsList43 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = ByteZhenWenn.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(ByteZhenWenn.evtTools.runtimeScene.wait(0.35), (runtimeScene) => (ByteZhenWenn.LobbyUICode.asyncCallback14463404(runtimeScene, asyncObjectsList)));
}
}

}


};ByteZhenWenn.LobbyUICode.asyncCallback14463132 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
ByteZhenWenn.copyArray(asyncObjectsList.getObjects("PowerBall"), ByteZhenWenn.LobbyUICode.GDPowerBallObjects7);

ByteZhenWenn.LobbyUICode.GDBonuseMultiplierObjects7.length = 0;

{ByteZhenWenn.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDBonuseMultiplierObjects7Objects, (( ByteZhenWenn.LobbyUICode.GDPowerBallObjects7.length === 0 ) ? 0 :ByteZhenWenn.LobbyUICode.GDPowerBallObjects7[0].getPointX("")) + 10, (( ByteZhenWenn.LobbyUICode.GDPowerBallObjects7.length === 0 ) ? 0 :ByteZhenWenn.LobbyUICode.GDPowerBallObjects7[0].getPointY("")) + 15, "");
}{ByteZhenWenn.evtTools.sound.playMusicOnChannel(runtimeScene, "Zhelong/assets-SongJia_0qobyicaae.mp3", 10, false, runtimeScene.getGame().getVariables().getFromIndex(14).getAsNumber(), 1);
}{ByteZhenWenn.evtTools.sound.playSound(runtimeScene, "Zhelong/assets-LiuJing_2fnrcmakj7.mp3", false, 80, 1);
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList43(runtimeScene, asyncObjectsList);} //End of subevents
ByteZhenWenn.LobbyUICode.localVariables.length = 0;
}
ByteZhenWenn.LobbyUICode.eventsList44 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = ByteZhenWenn.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
for (const obj of ByteZhenWenn.LobbyUICode.GDPowerBallObjects6) asyncObjectsList.addObject("PowerBall", obj);
runtimeScene.getAsyncTasksManager().addTask(ByteZhenWenn.evtTools.runtimeScene.wait(0.4), (runtimeScene) => (ByteZhenWenn.LobbyUICode.asyncCallback14463132(runtimeScene, asyncObjectsList)));
}
}

}


};ByteZhenWenn.LobbyUICode.eventsList45 = function(runtimeScene, asyncObjectsList) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(12).getAsNumber() > 1);
}
if (isConditionTrue_0) {
ByteZhenWenn.copyArray(runtimeScene.getObjects("GameBackgrond"), ByteZhenWenn.LobbyUICode.GDGameBackgrondObjects6);
ByteZhenWenn.copyArray(runtimeScene.getObjects("NewSprite"), ByteZhenWenn.LobbyUICode.GDNewSpriteObjects6);
ByteZhenWenn.LobbyUICode.GDSunBonuseObjects6.length = 0;

{ByteZhenWenn.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDSunBonuseObjects6Objects, 206, 137, "");
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDSunBonuseObjects6.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDSunBonuseObjects6[i].getBehavior("Resizable").setSize(332, 347);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDGameBackgrondObjects6.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDGameBackgrondObjects6[i].getBehavior("Animation").setAnimationName("bonuse");
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDGameBackgrondObjects6.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDGameBackgrondObjects6[i].getBehavior("Resizable").setSize(868, 1302);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDNewSpriteObjects6.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDNewSpriteObjects6[i].getBehavior("Animation").setAnimationName("Bonuse");
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDNewSpriteObjects6.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDNewSpriteObjects6[i].getBehavior("Resizable").setSize(766, 766);
}
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList44(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};ByteZhenWenn.LobbyUICode.asyncCallback14458196 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
ByteZhenWenn.copyArray(asyncObjectsList.getObjects("BlueFlame"), ByteZhenWenn.LobbyUICode.GDBlueFlameObjects6);

ByteZhenWenn.copyArray(asyncObjectsList.getObjects("NewLight"), ByteZhenWenn.LobbyUICode.GDNewLightObjects6);

ByteZhenWenn.copyArray(asyncObjectsList.getObjects("PowerBall"), ByteZhenWenn.LobbyUICode.GDPowerBallObjects6);

ByteZhenWenn.copyArray(asyncObjectsList.getObjects("SquirelBonus"), ByteZhenWenn.LobbyUICode.GDSquirelBonusObjects6);

ByteZhenWenn.copyArray(asyncObjectsList.getObjects("SquirrelIdle"), ByteZhenWenn.LobbyUICode.GDSquirrelIdleObjects6);

{ByteZhenWenn.evtTools.sound.setMusicOnChannelVolume(runtimeScene, 10, runtimeScene.getGame().getVariables().getFromIndex(14).getAsNumber());
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDSquirrelIdleObjects6.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDSquirrelIdleObjects6[i].getBehavior("Tween").addObjectPositionYTween2("idlehide", (ByteZhenWenn.LobbyUICode.GDSquirrelIdleObjects6[i].getPointY("")) - 300, "linear", 0.25, false);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDSquirelBonusObjects6.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDSquirelBonusObjects6[i].setX(955);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDPowerBallObjects6.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDPowerBallObjects6[i].getBehavior("Tween").addObjectPositionYTween2("powery", (ByteZhenWenn.LobbyUICode.GDPowerBallObjects6[i].getPointY("")) - 60, "linear", 0.2, false);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDPowerBallObjects6.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDPowerBallObjects6[i].getBehavior("Tween").addObjectPositionXTween2("powerx", (ByteZhenWenn.LobbyUICode.GDPowerBallObjects6[i].getPointX("")) + 10, "linear", 0.2, false);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDBlueFlameObjects6.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDBlueFlameObjects6[i].getBehavior("Tween").addObjectPositionYTween2("powerflame", (ByteZhenWenn.LobbyUICode.GDBlueFlameObjects6[i].getY()) - 60, "linear", 0.2, false);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDBlueFlameObjects6.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDBlueFlameObjects6[i].getBehavior("Tween").addObjectPositionXTween2("powerflamex", (ByteZhenWenn.LobbyUICode.GDBlueFlameObjects6[i].getX()) + 10, "linear", 0.2, false);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDNewLightObjects6.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDNewLightObjects6[i].deleteFromScene(runtimeScene);
}
}{ByteZhenWenn.evtTools.tween.tweenCameraZoom2(runtimeScene, "camerazoom", 1, "", "linear", 0.2);
}{runtimeScene.getGame().getVariables().getFromIndex(10).setBoolean(false);
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList45(runtimeScene, asyncObjectsList);} //End of subevents
ByteZhenWenn.LobbyUICode.localVariables.length = 0;
}
ByteZhenWenn.LobbyUICode.eventsList46 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = ByteZhenWenn.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
/* Don't save BlueFlame as it will be provided by the parent asyncObjectsList. */
/* Don't save NewLight as it will be provided by the parent asyncObjectsList. */
for (const obj of ByteZhenWenn.LobbyUICode.GDPowerBallObjects5) asyncObjectsList.addObject("PowerBall", obj);
/* Don't save SquirelBonus as it will be provided by the parent asyncObjectsList. */
/* Don't save SquirrelIdle as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(ByteZhenWenn.evtTools.runtimeScene.wait(1.25), (runtimeScene) => (ByteZhenWenn.LobbyUICode.asyncCallback14458196(runtimeScene, asyncObjectsList)));
}
}

}


};ByteZhenWenn.LobbyUICode.asyncCallback14458580 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
ByteZhenWenn.copyArray(asyncObjectsList.getObjects("PowerBall"), ByteZhenWenn.LobbyUICode.GDPowerBallObjects5);

ByteZhenWenn.LobbyUICode.GDMultiplierParticle3XObjects5.length = 0;

{ByteZhenWenn.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDMultiplierParticle3XObjects5Objects, (( ByteZhenWenn.LobbyUICode.GDPowerBallObjects5.length === 0 ) ? 0 :ByteZhenWenn.LobbyUICode.GDPowerBallObjects5[0].getPointX("")) + 20, (( ByteZhenWenn.LobbyUICode.GDPowerBallObjects5.length === 0 ) ? 0 :ByteZhenWenn.LobbyUICode.GDPowerBallObjects5[0].getPointY("")) + 50, "");
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList46(runtimeScene, asyncObjectsList);} //End of subevents
ByteZhenWenn.LobbyUICode.localVariables.length = 0;
}
ByteZhenWenn.LobbyUICode.eventsList47 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = ByteZhenWenn.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
/* Don't save BlueFlame as it will be provided by the parent asyncObjectsList. */
/* Don't save NewLight as it will be provided by the parent asyncObjectsList. */
for (const obj of ByteZhenWenn.LobbyUICode.GDPowerBallObjects4) asyncObjectsList.addObject("PowerBall", obj);
/* Don't save SquirelBonus as it will be provided by the parent asyncObjectsList. */
/* Don't save SquirrelIdle as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(ByteZhenWenn.evtTools.runtimeScene.wait(0.18), (runtimeScene) => (ByteZhenWenn.LobbyUICode.asyncCallback14458580(runtimeScene, asyncObjectsList)));
}
}

}


};ByteZhenWenn.LobbyUICode.asyncCallback14457900 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
ByteZhenWenn.copyArray(asyncObjectsList.getObjects("PowerBall"), ByteZhenWenn.LobbyUICode.GDPowerBallObjects4);

ByteZhenWenn.LobbyUICode.GDMultiplierParticle10XObjects4.length = 0;

{ByteZhenWenn.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDMultiplierParticle10XObjects4Objects, (( ByteZhenWenn.LobbyUICode.GDPowerBallObjects4.length === 0 ) ? 0 :ByteZhenWenn.LobbyUICode.GDPowerBallObjects4[0].getPointX("")) + 30, (( ByteZhenWenn.LobbyUICode.GDPowerBallObjects4.length === 0 ) ? 0 :ByteZhenWenn.LobbyUICode.GDPowerBallObjects4[0].getPointY("")) + 50, "");
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList47(runtimeScene, asyncObjectsList);} //End of subevents
ByteZhenWenn.LobbyUICode.localVariables.length = 0;
}
ByteZhenWenn.LobbyUICode.eventsList48 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = ByteZhenWenn.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
/* Don't save BlueFlame as it will be provided by the parent asyncObjectsList. */
/* Don't save NewLight as it will be provided by the parent asyncObjectsList. */
for (const obj of ByteZhenWenn.LobbyUICode.GDPowerBallObjects3) asyncObjectsList.addObject("PowerBall", obj);
/* Don't save SquirelBonus as it will be provided by the parent asyncObjectsList. */
/* Don't save SquirrelIdle as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(ByteZhenWenn.evtTools.runtimeScene.wait(0.28), (runtimeScene) => (ByteZhenWenn.LobbyUICode.asyncCallback14457900(runtimeScene, asyncObjectsList)));
}
}

}


};ByteZhenWenn.LobbyUICode.asyncCallback14457636 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
ByteZhenWenn.copyArray(asyncObjectsList.getObjects("PowerBall"), ByteZhenWenn.LobbyUICode.GDPowerBallObjects3);

ByteZhenWenn.LobbyUICode.GDMultiplierParticle5XObjects3.length = 0;

{ByteZhenWenn.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDMultiplierParticle5XObjects3Objects, (( ByteZhenWenn.LobbyUICode.GDPowerBallObjects3.length === 0 ) ? 0 :ByteZhenWenn.LobbyUICode.GDPowerBallObjects3[0].getPointX("")), (( ByteZhenWenn.LobbyUICode.GDPowerBallObjects3.length === 0 ) ? 0 :ByteZhenWenn.LobbyUICode.GDPowerBallObjects3[0].getPointY("")) + 50, "");
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList48(runtimeScene, asyncObjectsList);} //End of subevents
ByteZhenWenn.LobbyUICode.localVariables.length = 0;
}
ByteZhenWenn.LobbyUICode.eventsList49 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = ByteZhenWenn.LongLivedObjectsList.from(parentAsyncObjectsList);
asyncObjectsList.backupLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
for (const obj of ByteZhenWenn.LobbyUICode.GDBlueFlameObjects2) asyncObjectsList.addObject("BlueFlame", obj);
for (const obj of ByteZhenWenn.LobbyUICode.GDNewLightObjects2) asyncObjectsList.addObject("NewLight", obj);
for (const obj of ByteZhenWenn.LobbyUICode.GDPowerBallObjects2) asyncObjectsList.addObject("PowerBall", obj);
for (const obj of ByteZhenWenn.LobbyUICode.GDSquirelBonusObjects2) asyncObjectsList.addObject("SquirelBonus", obj);
/* Don't save SquirrelIdle as it will be provided by the parent asyncObjectsList. */
runtimeScene.getAsyncTasksManager().addTask(ByteZhenWenn.evtTools.runtimeScene.wait(0.28), (runtimeScene) => (ByteZhenWenn.LobbyUICode.asyncCallback14457636(runtimeScene, asyncObjectsList)));
}
}

}


};ByteZhenWenn.LobbyUICode.asyncCallback14454060 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
ByteZhenWenn.copyArray(runtimeScene.getObjects("BlueFlame"), ByteZhenWenn.LobbyUICode.GDBlueFlameObjects2);
ByteZhenWenn.copyArray(runtimeScene.getObjects("PowerBall"), ByteZhenWenn.LobbyUICode.GDPowerBallObjects2);
ByteZhenWenn.copyArray(runtimeScene.getObjects("SquirelBonus"), ByteZhenWenn.LobbyUICode.GDSquirelBonusObjects2);
ByteZhenWenn.LobbyUICode.GDMultiplierParticle2XObjects2.length = 0;

ByteZhenWenn.LobbyUICode.GDNewLightObjects2.length = 0;

{runtimeScene.getGame().getVariables().getFromIndex(10).setBoolean(true);
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDSquirelBonusObjects2.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDSquirelBonusObjects2[i].setX(155);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDSquirelBonusObjects2.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDSquirelBonusObjects2[i].setY(420);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDSquirelBonusObjects2.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDSquirelBonusObjects2[i].getBehavior("Tween").addObjectPositionYTween2("idlehide", 140, "linear", 0.25, false);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDPowerBallObjects2.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDPowerBallObjects2[i].getBehavior("Tween").addObjectPositionYTween2("powery", (ByteZhenWenn.LobbyUICode.GDPowerBallObjects2[i].getPointY("")) + 60, "linear", 0.2, false);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDPowerBallObjects2.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDPowerBallObjects2[i].getBehavior("Tween").addObjectPositionXTween2("powerx", (ByteZhenWenn.LobbyUICode.GDPowerBallObjects2[i].getPointX("")) - 10, "linear", 0.2, false);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDBlueFlameObjects2.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDBlueFlameObjects2[i].getBehavior("Tween").addObjectPositionYTween2("powerflame", (ByteZhenWenn.LobbyUICode.GDBlueFlameObjects2[i].getY()) + 60, "linear", 0.2, false);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDBlueFlameObjects2.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDBlueFlameObjects2[i].getBehavior("Tween").addObjectPositionXTween2("powerflamex", (ByteZhenWenn.LobbyUICode.GDBlueFlameObjects2[i].getX()) - 10, "linear", 0.2, false);
}
}{ByteZhenWenn.evtTools.tween.tweenCameraZoom2(runtimeScene, "camerazoom", 0.94, "", "linear", 2.0);
}{ByteZhenWenn.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDNewLightObjects2Objects, 367, 365, "");
}{ByteZhenWenn.evtTools.sound.setMusicOnChannelVolume(runtimeScene, 10, runtimeScene.getGame().getVariables().getFromIndex(14).getAsNumber());
}{ByteZhenWenn.evtTools.sound.fadeMusicVolume(runtimeScene, 10, runtimeScene.getGame().getVariables().getFromIndex(15).getAsNumber(), 1);
}{ByteZhenWenn.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDMultiplierParticle2XObjects2Objects, (( ByteZhenWenn.LobbyUICode.GDPowerBallObjects2.length === 0 ) ? 0 :ByteZhenWenn.LobbyUICode.GDPowerBallObjects2[0].getPointX("")) + 30, (( ByteZhenWenn.LobbyUICode.GDPowerBallObjects2.length === 0 ) ? 0 :ByteZhenWenn.LobbyUICode.GDPowerBallObjects2[0].getPointY("")) + 50, "");
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList49(runtimeScene, asyncObjectsList);} //End of subevents
ByteZhenWenn.LobbyUICode.localVariables.length = 0;
}
ByteZhenWenn.LobbyUICode.eventsList50 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new ByteZhenWenn.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
for (const obj of ByteZhenWenn.LobbyUICode.GDSquirrelIdleObjects1) asyncObjectsList.addObject("SquirrelIdle", obj);
runtimeScene.getAsyncTasksManager().addTask(ByteZhenWenn.evtTools.runtimeScene.wait(0.26), (runtimeScene) => (ByteZhenWenn.LobbyUICode.asyncCallback14454060(runtimeScene, asyncObjectsList)));
}
}

}


};ByteZhenWenn.LobbyUICode.eventsList51 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(2).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(12).getAsNumber() < 2);
}
}
if (isConditionTrue_0) {
ByteZhenWenn.copyArray(runtimeScene.getObjects("SquirrelIdle"), ByteZhenWenn.LobbyUICode.GDSquirrelIdleObjects1);
{runtimeScene.getGame().getVariables().getFromIndex(2).setBoolean(false);
}{runtimeScene.getGame().getVariables().getFromIndex(10).setBoolean(true);
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDSquirrelIdleObjects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDSquirrelIdleObjects1[i].getBehavior("Tween").addObjectPositionYTween2("idlehide", (ByteZhenWenn.LobbyUICode.GDSquirrelIdleObjects1[i].getPointY("")) + 300, "linear", 0.25, false);
}
}{ByteZhenWenn.evtTools.sound.setMusicOnChannelVolume(runtimeScene, 10, runtimeScene.getGame().getVariables().getFromIndex(15).getAsNumber());
}{ByteZhenWenn.evtTools.sound.playSound(runtimeScene, "Zhelong/assets-ZhaoYue_b2vqsrmk3q.mp3", false, 80, 1);
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList50(runtimeScene);} //End of subevents
}

}


};ByteZhenWenn.LobbyUICode.eventsList52 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
ByteZhenWenn.copyArray(runtimeScene.getObjects("BetAmount"), ByteZhenWenn.LobbyUICode.GDBetAmountObjects1);
ByteZhenWenn.copyArray(runtimeScene.getObjects("BonuseMultiplier"), ByteZhenWenn.LobbyUICode.GDBonuseMultiplierObjects1);
ByteZhenWenn.copyArray(runtimeScene.getObjects("PlayerBalance"), ByteZhenWenn.LobbyUICode.GDPlayerBalanceObjects1);
ByteZhenWenn.copyArray(runtimeScene.getObjects("PlayerID"), ByteZhenWenn.LobbyUICode.GDPlayerIDObjects1);
ByteZhenWenn.copyArray(runtimeScene.getObjects("WinAmount"), ByteZhenWenn.LobbyUICode.GDWinAmountObjects1);
{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDBetAmountObjects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDBetAmountObjects1[i].getBehavior("Text").setText("R$ " + ByteZhenWenn.evtsExt__ExtendedMath__ToFixedString.func(runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber(), 2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDPlayerIDObjects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDPlayerIDObjects1[i].getBehavior("Text").setText("Identificação: " + runtimeScene.getGame().getVariables().getFromIndex(4).getAsString());
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDPlayerBalanceObjects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDPlayerBalanceObjects1[i].getBehavior("Text").setText("BRL " + ByteZhenWenn.evtsExt__ExtendedMath__ToFixedString.func(runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(5).getAsNumber(), 2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDWinAmountObjects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDWinAmountObjects1[i].getBehavior("Text").setText("R$ " + ByteZhenWenn.evtsExt__ExtendedMath__ToFixedString.func(runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(7).getAsNumber(), 2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDBonuseMultiplierObjects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDBonuseMultiplierObjects1[i].getBehavior("Text").setText("X" + runtimeScene.getGame().getVariables().getFromIndex(12).getAsString());
}
}}

}


};ByteZhenWenn.LobbyUICode.userFunc0x98f190 = function GDJSInlineCode(runtimeScene) {
"use strict";
window.parent.postMessage({ type: 'message', data: 'open_profile' }, window.location.origin);
};
ByteZhenWenn.LobbyUICode.eventsList53 = function(runtimeScene) {

{


ByteZhenWenn.LobbyUICode.userFunc0x98f190(runtimeScene);

}


};ByteZhenWenn.LobbyUICode.userFunc0xe8a638 = function GDJSInlineCode(runtimeScene) {
"use strict";
window.parent.postMessage({ type: 'message', data: 'open_rules' }, window.location.origin);
};
ByteZhenWenn.LobbyUICode.eventsList54 = function(runtimeScene) {

{


ByteZhenWenn.LobbyUICode.userFunc0xe8a638(runtimeScene);

}


};ByteZhenWenn.LobbyUICode.userFunc0xe8a918 = function GDJSInlineCode(runtimeScene) {
"use strict";
window.parent.postMessage({ type: 'message', data: 'open_profile' }, window.location.origin);
};
ByteZhenWenn.LobbyUICode.eventsList55 = function(runtimeScene) {

{


ByteZhenWenn.LobbyUICode.userFunc0xe8a918(runtimeScene);

}


};ByteZhenWenn.LobbyUICode.userFunc0xa45f58 = function GDJSInlineCode(runtimeScene) {
"use strict";
window.parent.postMessage({ type: 'message', data: 'open_deposit' }, window.location.origin);
};
ByteZhenWenn.LobbyUICode.eventsList56 = function(runtimeScene) {

{


ByteZhenWenn.LobbyUICode.userFunc0xa45f58(runtimeScene);

}


};ByteZhenWenn.LobbyUICode.userFunc0x88d4f8 = function GDJSInlineCode(runtimeScene) {
"use strict";
window.parent.postMessage({ type: 'message', data: 'open_social' }, window.location.origin);
};
ByteZhenWenn.LobbyUICode.eventsList57 = function(runtimeScene) {

{


ByteZhenWenn.LobbyUICode.userFunc0x88d4f8(runtimeScene);

}


};ByteZhenWenn.LobbyUICode.userFunc0x88d7a8 = function GDJSInlineCode(runtimeScene) {
"use strict";
window.parent.postMessage({ type: 'message', data: 'open_share' }, window.location.origin);
};
ByteZhenWenn.LobbyUICode.eventsList58 = function(runtimeScene) {

{


ByteZhenWenn.LobbyUICode.userFunc0x88d7a8(runtimeScene);

}


};ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDLockObjects1Objects = Hashtable.newFrom({"Lock": ByteZhenWenn.LobbyUICode.GDLockObjects1});
ByteZhenWenn.LobbyUICode.asyncCallback14475972 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
ByteZhenWenn.copyArray(runtimeScene.getObjects("GameBackgrond"), ByteZhenWenn.LobbyUICode.GDGameBackgrondObjects2);
ByteZhenWenn.copyArray(asyncObjectsList.getObjects("Lock"), ByteZhenWenn.LobbyUICode.GDLockObjects2);

ByteZhenWenn.copyArray(runtimeScene.getObjects("NewSprite"), ByteZhenWenn.LobbyUICode.GDNewSpriteObjects2);
{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDGameBackgrondObjects2.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDGameBackgrondObjects2[i].getBehavior("Animation").setAnimationName("common");
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDGameBackgrondObjects2.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDGameBackgrondObjects2[i].getBehavior("Resizable").setSize(868, 1302);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDNewSpriteObjects2.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDNewSpriteObjects2[i].getBehavior("Animation").setAnimationName("Common");
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDNewSpriteObjects2.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDNewSpriteObjects2[i].getBehavior("Resizable").setSize(766, 766);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDLockObjects2.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDLockObjects2[i].getBehavior("Tween").addObjectOpacityTween2("recoverylock", 255, "linear", 1.6, false);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDLockObjects2.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDLockObjects2[i].setZOrder(9999);
}
}{runtimeScene.getGame().getVariables().getFromIndex(10).setBoolean(false);
}{ByteZhenWenn.evtTools.sound.playSound(runtimeScene, "Zhelong/assets-ZhuJing_dd5ipsbvu5.mp3", false, 95, 1);
}ByteZhenWenn.LobbyUICode.localVariables.length = 0;
}
ByteZhenWenn.LobbyUICode.eventsList59 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new ByteZhenWenn.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
for (const obj of ByteZhenWenn.LobbyUICode.GDLockObjects1) asyncObjectsList.addObject("Lock", obj);
runtimeScene.getAsyncTasksManager().addTask(ByteZhenWenn.evtTools.runtimeScene.wait(0.38), (runtimeScene) => (ByteZhenWenn.LobbyUICode.asyncCallback14475972(runtimeScene, asyncObjectsList)));
}
}

}


};ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDLockObjects1Objects = Hashtable.newFrom({"Lock": ByteZhenWenn.LobbyUICode.GDLockObjects1});
ByteZhenWenn.LobbyUICode.asyncCallback14482772 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
ByteZhenWenn.copyArray(runtimeScene.getObjects("GameBackgrond"), ByteZhenWenn.LobbyUICode.GDGameBackgrondObjects2);
ByteZhenWenn.copyArray(asyncObjectsList.getObjects("Lock"), ByteZhenWenn.LobbyUICode.GDLockObjects2);

ByteZhenWenn.copyArray(runtimeScene.getObjects("NewSprite"), ByteZhenWenn.LobbyUICode.GDNewSpriteObjects2);
{runtimeScene.getGame().getVariables().getFromIndex(1).setBoolean(false);
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDGameBackgrondObjects2.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDGameBackgrondObjects2[i].getBehavior("Animation").setAnimationName("common");
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDGameBackgrondObjects2.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDGameBackgrondObjects2[i].getBehavior("Resizable").setSize(868, 1302);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDNewSpriteObjects2.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDNewSpriteObjects2[i].getBehavior("Animation").setAnimationName("Common");
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDNewSpriteObjects2.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDNewSpriteObjects2[i].getBehavior("Resizable").setSize(766, 766);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDLockObjects2.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDLockObjects2[i].getBehavior("Tween").addObjectOpacityTween2("recoverylock", 255, "linear", 1.6, false);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDLockObjects2.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDLockObjects2[i].setZOrder(9999);
}
}{runtimeScene.getGame().getVariables().getFromIndex(10).setBoolean(false);
}ByteZhenWenn.LobbyUICode.localVariables.length = 0;
}
ByteZhenWenn.LobbyUICode.eventsList60 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new ByteZhenWenn.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(ByteZhenWenn.LobbyUICode.localVariables);
for (const obj of ByteZhenWenn.LobbyUICode.GDLockObjects1) asyncObjectsList.addObject("Lock", obj);
runtimeScene.getAsyncTasksManager().addTask(ByteZhenWenn.evtTools.runtimeScene.wait(0.18), (runtimeScene) => (ByteZhenWenn.LobbyUICode.asyncCallback14482772(runtimeScene, asyncObjectsList)));
}
}

}


};ByteZhenWenn.LobbyUICode.eventsList61 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = ByteZhenWenn.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{ByteZhenWenn.evtTools.sound.playMusicOnChannel(runtimeScene, "Zhelong/assets-LiJia_z9cbchsw3b.mp3", 10, true, runtimeScene.getGame().getVariables().getFromIndex(14).getAsNumber(), 1);
}{ByteZhenWenn.evtsExt__WeiZhenCore_Game__Core_Start.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList0(runtimeScene);} //End of subevents
}

}


{

ByteZhenWenn.copyArray(runtimeScene.getObjects("SpinButton"), ByteZhenWenn.LobbyUICode.GDSpinButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = ByteZhenWenn.LobbyUICode.GDSpinButtonObjects1.length;i<l;++i) {
    if ( ByteZhenWenn.LobbyUICode.GDSpinButtonObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        ByteZhenWenn.LobbyUICode.GDSpinButtonObjects1[k] = ByteZhenWenn.LobbyUICode.GDSpinButtonObjects1[i];
        ++k;
    }
}
ByteZhenWenn.LobbyUICode.GDSpinButtonObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getGame().getVariables().getFromIndex(1).getAsBoolean();
}
}
if (isConditionTrue_0) {
ByteZhenWenn.copyArray(runtimeScene.getObjects("SpinMainButton"), ByteZhenWenn.LobbyUICode.GDSpinMainButtonObjects1);
ByteZhenWenn.copyArray(runtimeScene.getObjects("prize_00"), ByteZhenWenn.LobbyUICode.GDprize_959500Objects1);
ByteZhenWenn.copyArray(runtimeScene.getObjects("prize_01"), ByteZhenWenn.LobbyUICode.GDprize_959501Objects1);
ByteZhenWenn.copyArray(runtimeScene.getObjects("prize_02"), ByteZhenWenn.LobbyUICode.GDprize_959502Objects1);
ByteZhenWenn.copyArray(runtimeScene.getObjects("prize_03"), ByteZhenWenn.LobbyUICode.GDprize_959503Objects1);
ByteZhenWenn.copyArray(runtimeScene.getObjects("prize_04"), ByteZhenWenn.LobbyUICode.GDprize_959504Objects1);
ByteZhenWenn.copyArray(runtimeScene.getObjects("prize_fox"), ByteZhenWenn.LobbyUICode.GDprize_9595foxObjects1);
ByteZhenWenn.LobbyUICode.GDPulseParticleObjects1.length = 0;

{runtimeScene.getGame().getVariables().getFromIndex(12).setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(0);
}{ByteZhenWenn.evtTools.sound.playSound(runtimeScene, "Zhelong/assets-LiuJia_l51a6aqquv.mp3", false, 80, 1);
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDprize_9595foxObjects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDprize_9595foxObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDprize_959504Objects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDprize_959504Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDprize_959502Objects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDprize_959502Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDprize_959501Objects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDprize_959501Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDprize_959500Objects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDprize_959500Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDprize_959503Objects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDprize_959503Objects1[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getGame().getVariables().getFromIndex(1).setBoolean(true);
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDSpinMainButtonObjects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDSpinMainButtonObjects1[i].getBehavior("Tween").addObjectScaleTween3("scale", (ByteZhenWenn.LobbyUICode.GDSpinMainButtonObjects1[i].getBehavior("Scale").getScale()) + 0.09, "linear", 0.15, false, true);
}
}{ByteZhenWenn.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDPulseParticleObjects1Objects, (( ByteZhenWenn.LobbyUICode.GDSpinMainButtonObjects1.length === 0 ) ? 0 :ByteZhenWenn.LobbyUICode.GDSpinMainButtonObjects1[0].getPointX("")) + 100, (( ByteZhenWenn.LobbyUICode.GDSpinMainButtonObjects1.length === 0 ) ? 0 :ByteZhenWenn.LobbyUICode.GDSpinMainButtonObjects1[0].getPointY("")) + 108, "");
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList3(runtimeScene);} //End of subevents
}

}


{

ByteZhenWenn.copyArray(runtimeScene.getObjects("SpinButton"), ByteZhenWenn.LobbyUICode.GDSpinButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = ByteZhenWenn.LobbyUICode.GDSpinButtonObjects1.length;i<l;++i) {
    if ( ByteZhenWenn.LobbyUICode.GDSpinButtonObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        ByteZhenWenn.LobbyUICode.GDSpinButtonObjects1[k] = ByteZhenWenn.LobbyUICode.GDSpinButtonObjects1[i];
        ++k;
    }
}
ByteZhenWenn.LobbyUICode.GDSpinButtonObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getGame().getVariables().getFromIndex(17).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(1).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(7).getAsNumber() > 0);
}
}
}
}
if (isConditionTrue_0) {
ByteZhenWenn.copyArray(runtimeScene.getObjects("ReceiveWin"), ByteZhenWenn.LobbyUICode.GDReceiveWinObjects1);
{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDReceiveWinObjects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDReceiveWinObjects1[i].getBehavior("Text").setText("BRL " + ByteZhenWenn.evtsExt__ExtendedMath__ToFixedString.func(runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(7).getAsNumber(), 2, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
}{ByteZhenWenn.evtTools.camera.showLayer(runtimeScene, "Bonus Screen");
}{ByteZhenWenn.evtTools.sound.playSound(runtimeScene, "Zhelong/assets-ChenYue_9a2hq2yxkg.mp3", false, 100, 1);
}{runtimeScene.getGame().getVariables().getFromIndex(13).setBoolean(true);
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList5(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(0).getAsBoolean();
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setBoolean(false);
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList9(runtimeScene);} //End of subevents
}

}


{


ByteZhenWenn.LobbyUICode.eventsList37(runtimeScene);
}


{


ByteZhenWenn.LobbyUICode.eventsList42(runtimeScene);
}


{


ByteZhenWenn.LobbyUICode.eventsList51(runtimeScene);
}


{


ByteZhenWenn.LobbyUICode.eventsList52(runtimeScene);
}


{

ByteZhenWenn.copyArray(runtimeScene.getObjects("Perfil"), ByteZhenWenn.LobbyUICode.GDPerfilObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = ByteZhenWenn.LobbyUICode.GDPerfilObjects1.length;i<l;++i) {
    if ( ByteZhenWenn.LobbyUICode.GDPerfilObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        ByteZhenWenn.LobbyUICode.GDPerfilObjects1[k] = ByteZhenWenn.LobbyUICode.GDPerfilObjects1[i];
        ++k;
    }
}
ByteZhenWenn.LobbyUICode.GDPerfilObjects1.length = k;
if (isConditionTrue_0) {

{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList53(runtimeScene);} //End of subevents
}

}


{

ByteZhenWenn.copyArray(runtimeScene.getObjects("ui_rules"), ByteZhenWenn.LobbyUICode.GDui_9595rulesObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = ByteZhenWenn.LobbyUICode.GDui_9595rulesObjects1.length;i<l;++i) {
    if ( ByteZhenWenn.LobbyUICode.GDui_9595rulesObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        ByteZhenWenn.LobbyUICode.GDui_9595rulesObjects1[k] = ByteZhenWenn.LobbyUICode.GDui_9595rulesObjects1[i];
        ++k;
    }
}
ByteZhenWenn.LobbyUICode.GDui_9595rulesObjects1.length = k;
if (isConditionTrue_0) {

{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList54(runtimeScene);} //End of subevents
}

}


{

ByteZhenWenn.copyArray(runtimeScene.getObjects("Profile"), ByteZhenWenn.LobbyUICode.GDProfileObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = ByteZhenWenn.LobbyUICode.GDProfileObjects1.length;i<l;++i) {
    if ( ByteZhenWenn.LobbyUICode.GDProfileObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        ByteZhenWenn.LobbyUICode.GDProfileObjects1[k] = ByteZhenWenn.LobbyUICode.GDProfileObjects1[i];
        ++k;
    }
}
ByteZhenWenn.LobbyUICode.GDProfileObjects1.length = k;
if (isConditionTrue_0) {

{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList55(runtimeScene);} //End of subevents
}

}


{

ByteZhenWenn.copyArray(runtimeScene.getObjects("DepositButton"), ByteZhenWenn.LobbyUICode.GDDepositButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = ByteZhenWenn.LobbyUICode.GDDepositButtonObjects1.length;i<l;++i) {
    if ( ByteZhenWenn.LobbyUICode.GDDepositButtonObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        ByteZhenWenn.LobbyUICode.GDDepositButtonObjects1[k] = ByteZhenWenn.LobbyUICode.GDDepositButtonObjects1[i];
        ++k;
    }
}
ByteZhenWenn.LobbyUICode.GDDepositButtonObjects1.length = k;
if (isConditionTrue_0) {

{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList56(runtimeScene);} //End of subevents
}

}


{

ByteZhenWenn.copyArray(runtimeScene.getObjects("Ui_SOCIAL"), ByteZhenWenn.LobbyUICode.GDUi_9595SOCIALObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = ByteZhenWenn.LobbyUICode.GDUi_9595SOCIALObjects1.length;i<l;++i) {
    if ( ByteZhenWenn.LobbyUICode.GDUi_9595SOCIALObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        ByteZhenWenn.LobbyUICode.GDUi_9595SOCIALObjects1[k] = ByteZhenWenn.LobbyUICode.GDUi_9595SOCIALObjects1[i];
        ++k;
    }
}
ByteZhenWenn.LobbyUICode.GDUi_9595SOCIALObjects1.length = k;
if (isConditionTrue_0) {

{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList57(runtimeScene);} //End of subevents
}

}


{

ByteZhenWenn.copyArray(runtimeScene.getObjects("IndiqueGanhe"), ByteZhenWenn.LobbyUICode.GDIndiqueGanheObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = ByteZhenWenn.LobbyUICode.GDIndiqueGanheObjects1.length;i<l;++i) {
    if ( ByteZhenWenn.LobbyUICode.GDIndiqueGanheObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        ByteZhenWenn.LobbyUICode.GDIndiqueGanheObjects1[k] = ByteZhenWenn.LobbyUICode.GDIndiqueGanheObjects1[i];
        ++k;
    }
}
ByteZhenWenn.LobbyUICode.GDIndiqueGanheObjects1.length = k;
if (isConditionTrue_0) {

{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList58(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(6).getAsBoolean();
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(6).setBoolean(false);
}{ByteZhenWenn.evtTools.sound.playSound(runtimeScene, "Zhelong/assets-ZhaoTing_o3j8nzmqym.wav", false, 80, 1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(11).getAsBoolean();
}
if (isConditionTrue_0) {
ByteZhenWenn.copyArray(runtimeScene.getObjects("BonuseMultiplier"), ByteZhenWenn.LobbyUICode.GDBonuseMultiplierObjects1);
ByteZhenWenn.copyArray(runtimeScene.getObjects("ChestCollect"), ByteZhenWenn.LobbyUICode.GDChestCollectObjects1);
ByteZhenWenn.copyArray(runtimeScene.getObjects("SunBonuse"), ByteZhenWenn.LobbyUICode.GDSunBonuseObjects1);
ByteZhenWenn.copyArray(runtimeScene.getObjects("collect_text"), ByteZhenWenn.LobbyUICode.GDcollect_9595textObjects1);
ByteZhenWenn.LobbyUICode.GDLockObjects1.length = 0;

{runtimeScene.getGame().getVariables().getFromIndex(11).setBoolean(false);
}{runtimeScene.getGame().getVariables().getFromIndex(17).setBoolean(true);
}{runtimeScene.getGame().getVariables().getFromIndex(2).setBoolean(false);
}{runtimeScene.getGame().getVariables().getFromIndex(1).setBoolean(false);
}{ByteZhenWenn.evtTools.sound.playMusicOnChannel(runtimeScene, "Zhelong/assets-LiJia_z9cbchsw3b.mp3", 10, true, runtimeScene.getGame().getVariables().getFromIndex(14).getAsNumber(), 1);
}{runtimeScene.getGame().getVariables().getFromIndex(12).setNumber(0);
}{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(0);
}{ByteZhenWenn.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDLockObjects1Objects, 72, 523, "");
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDLockObjects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDLockObjects1[i].getBehavior("Resizable").setSize(571, 571);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDLockObjects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDLockObjects1[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDBonuseMultiplierObjects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDBonuseMultiplierObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChestCollectObjects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChestCollectObjects1[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDcollect_9595textObjects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDcollect_9595textObjects1[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDSunBonuseObjects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDSunBonuseObjects1[i].getBehavior("Opacity").setOpacity(0);
}
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList59(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(13).getAsBoolean();
}
if (isConditionTrue_0) {
ByteZhenWenn.copyArray(runtimeScene.getObjects("BonuseMultiplier"), ByteZhenWenn.LobbyUICode.GDBonuseMultiplierObjects1);
ByteZhenWenn.copyArray(runtimeScene.getObjects("Chest1"), ByteZhenWenn.LobbyUICode.GDChest1Objects1);
ByteZhenWenn.copyArray(runtimeScene.getObjects("Chest2"), ByteZhenWenn.LobbyUICode.GDChest2Objects1);
ByteZhenWenn.copyArray(runtimeScene.getObjects("Chest3"), ByteZhenWenn.LobbyUICode.GDChest3Objects1);
ByteZhenWenn.copyArray(runtimeScene.getObjects("Chest4"), ByteZhenWenn.LobbyUICode.GDChest4Objects1);
ByteZhenWenn.copyArray(runtimeScene.getObjects("Chest5"), ByteZhenWenn.LobbyUICode.GDChest5Objects1);
ByteZhenWenn.copyArray(runtimeScene.getObjects("Chest6"), ByteZhenWenn.LobbyUICode.GDChest6Objects1);
ByteZhenWenn.copyArray(runtimeScene.getObjects("Chest7"), ByteZhenWenn.LobbyUICode.GDChest7Objects1);
ByteZhenWenn.copyArray(runtimeScene.getObjects("Chest8"), ByteZhenWenn.LobbyUICode.GDChest8Objects1);
ByteZhenWenn.copyArray(runtimeScene.getObjects("Chest9"), ByteZhenWenn.LobbyUICode.GDChest9Objects1);
ByteZhenWenn.copyArray(runtimeScene.getObjects("ChestCollect"), ByteZhenWenn.LobbyUICode.GDChestCollectObjects1);
ByteZhenWenn.copyArray(runtimeScene.getObjects("SunBonuse"), ByteZhenWenn.LobbyUICode.GDSunBonuseObjects1);
ByteZhenWenn.copyArray(runtimeScene.getObjects("collect_text"), ByteZhenWenn.LobbyUICode.GDcollect_9595textObjects1);
ByteZhenWenn.copyArray(runtimeScene.getObjects("prize_00"), ByteZhenWenn.LobbyUICode.GDprize_959500Objects1);
ByteZhenWenn.copyArray(runtimeScene.getObjects("prize_01"), ByteZhenWenn.LobbyUICode.GDprize_959501Objects1);
ByteZhenWenn.copyArray(runtimeScene.getObjects("prize_02"), ByteZhenWenn.LobbyUICode.GDprize_959502Objects1);
ByteZhenWenn.copyArray(runtimeScene.getObjects("prize_03"), ByteZhenWenn.LobbyUICode.GDprize_959503Objects1);
ByteZhenWenn.copyArray(runtimeScene.getObjects("prize_04"), ByteZhenWenn.LobbyUICode.GDprize_959504Objects1);
ByteZhenWenn.copyArray(runtimeScene.getObjects("prize_fox"), ByteZhenWenn.LobbyUICode.GDprize_9595foxObjects1);
ByteZhenWenn.LobbyUICode.GDLockObjects1.length = 0;

{ByteZhenWenn.evtTools.sound.playMusicOnChannel(runtimeScene, "Zhelong/assets-LiJia_z9cbchsw3b.mp3", 10, true, runtimeScene.getGame().getVariables().getFromIndex(14).getAsNumber(), 1);
}{runtimeScene.getGame().getVariables().getFromIndex(2).setBoolean(false);
}{runtimeScene.getGame().getVariables().getFromIndex(13).setBoolean(false);
}{runtimeScene.getGame().getVariables().getFromIndex(12).setNumber(0);
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest1Objects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest1Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest2Objects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest2Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest3Objects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest3Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest4Objects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest4Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest5Objects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest5Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest6Objects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest6Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest7Objects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest7Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest8Objects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest8Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDprize_959504Objects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDprize_959504Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDprize_959501Objects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDprize_959501Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDprize_959502Objects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDprize_959502Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDprize_959500Objects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDprize_959500Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDprize_959503Objects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDprize_959503Objects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDprize_9595foxObjects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDprize_9595foxObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChest9Objects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChest9Objects1[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(0);
}{ByteZhenWenn.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), ByteZhenWenn.LobbyUICode.mapOfGDgdjs_9546LobbyUICode_9546GDLockObjects1Objects, 72, 523, "");
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDLockObjects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDLockObjects1[i].getBehavior("Resizable").setSize(571, 571);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDLockObjects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDLockObjects1[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDBonuseMultiplierObjects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDBonuseMultiplierObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDChestCollectObjects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDChestCollectObjects1[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDcollect_9595textObjects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDcollect_9595textObjects1[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = ByteZhenWenn.LobbyUICode.GDSunBonuseObjects1.length ;i < len;++i) {
    ByteZhenWenn.LobbyUICode.GDSunBonuseObjects1[i].getBehavior("Opacity").setOpacity(0);
}
}
{ //Subevents
ByteZhenWenn.LobbyUICode.eventsList60(runtimeScene);} //End of subevents
}

}


};

ByteZhenWenn.LobbyUICode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

ByteZhenWenn.LobbyUICode.GDGameBackgrondObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDGameBackgrondObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDGameBackgrondObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDGameBackgrondObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDGameBackgrondObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDGameBackgrondObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDGameBackgrondObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDGameBackgrondObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDLogoObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDLogoObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDLogoObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDLogoObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDLogoObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDLogoObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDLogoObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDLogoObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDHeader_9595UIObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDHeader_9595UIObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDHeader_9595UIObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDHeader_9595UIObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDHeader_9595UIObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDHeader_9595UIObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDHeader_9595UIObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDHeader_9595UIObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDPlayerIDObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDPlayerIDObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDPlayerIDObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDPlayerIDObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDPlayerIDObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDPlayerIDObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDPlayerIDObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDPlayerIDObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDPlayerBalanceObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDPlayerBalanceObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDPlayerBalanceObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDPlayerBalanceObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDPlayerBalanceObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDPlayerBalanceObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDPlayerBalanceObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDPlayerBalanceObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDIndiqueGanheObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDIndiqueGanheObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDIndiqueGanheObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDIndiqueGanheObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDIndiqueGanheObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDIndiqueGanheObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDIndiqueGanheObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDIndiqueGanheObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDGasObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDGasObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDGasObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDGasObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDGasObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDGasObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDGasObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDGasObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSpriteObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSpriteObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSpriteObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSpriteObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSpriteObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSpriteObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSpriteObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSpriteObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDUi_9595SOCIALObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDUi_9595SOCIALObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDUi_9595SOCIALObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDUi_9595SOCIALObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDUi_9595SOCIALObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDUi_9595SOCIALObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDUi_9595SOCIALObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDUi_9595SOCIALObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDUI_9595SupportObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDUI_9595SupportObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDUI_9595SupportObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDUI_9595SupportObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDUI_9595SupportObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDUI_9595SupportObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDUI_9595SupportObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDUI_9595SupportObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDSquirrelIdleObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDSquirrelIdleObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDSquirrelIdleObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDSquirrelIdleObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDSquirrelIdleObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDSquirrelIdleObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDSquirrelIdleObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDSquirrelIdleObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDPowerBallObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDPowerBallObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDPowerBallObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDPowerBallObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDPowerBallObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDPowerBallObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDPowerBallObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDPowerBallObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDBlueFlameObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDBlueFlameObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDBlueFlameObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDBlueFlameObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDBlueFlameObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDBlueFlameObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDBlueFlameObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDBlueFlameObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinMainButtonObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinMainButtonObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinMainButtonObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinMainButtonObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinMainButtonObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinMainButtonObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinMainButtonObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinMainButtonObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSprite3Objects1.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSprite3Objects2.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSprite3Objects3.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSprite3Objects4.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSprite3Objects5.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSprite3Objects6.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSprite3Objects7.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSprite3Objects8.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinButtonObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinButtonObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinButtonObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinButtonObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinButtonObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinButtonObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinButtonObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinButtonObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDPlusObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDPlusObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDPlusObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDPlusObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDPlusObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDPlusObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDPlusObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDPlusObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDMinusObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDMinusObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDMinusObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDMinusObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDMinusObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDMinusObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDMinusObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDMinusObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDBetAmountObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDBetAmountObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDBetAmountObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDBetAmountObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDBetAmountObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDBetAmountObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDBetAmountObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDBetAmountObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDWinAmountObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDWinAmountObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDWinAmountObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDWinAmountObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDWinAmountObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDWinAmountObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDWinAmountObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDWinAmountObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDLockObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDLockObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDLockObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDLockObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDLockObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDLockObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDLockObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDLockObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinMagicObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinMagicObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinMagicObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinMagicObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinMagicObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinMagicObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinMagicObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinMagicObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDPulseParticleObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDPulseParticleObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDPulseParticleObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDPulseParticleObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDPulseParticleObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDPulseParticleObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDPulseParticleObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDPulseParticleObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDChest1Objects1.length = 0;
ByteZhenWenn.LobbyUICode.GDChest1Objects2.length = 0;
ByteZhenWenn.LobbyUICode.GDChest1Objects3.length = 0;
ByteZhenWenn.LobbyUICode.GDChest1Objects4.length = 0;
ByteZhenWenn.LobbyUICode.GDChest1Objects5.length = 0;
ByteZhenWenn.LobbyUICode.GDChest1Objects6.length = 0;
ByteZhenWenn.LobbyUICode.GDChest1Objects7.length = 0;
ByteZhenWenn.LobbyUICode.GDChest1Objects8.length = 0;
ByteZhenWenn.LobbyUICode.GDChest2Objects1.length = 0;
ByteZhenWenn.LobbyUICode.GDChest2Objects2.length = 0;
ByteZhenWenn.LobbyUICode.GDChest2Objects3.length = 0;
ByteZhenWenn.LobbyUICode.GDChest2Objects4.length = 0;
ByteZhenWenn.LobbyUICode.GDChest2Objects5.length = 0;
ByteZhenWenn.LobbyUICode.GDChest2Objects6.length = 0;
ByteZhenWenn.LobbyUICode.GDChest2Objects7.length = 0;
ByteZhenWenn.LobbyUICode.GDChest2Objects8.length = 0;
ByteZhenWenn.LobbyUICode.GDChest3Objects1.length = 0;
ByteZhenWenn.LobbyUICode.GDChest3Objects2.length = 0;
ByteZhenWenn.LobbyUICode.GDChest3Objects3.length = 0;
ByteZhenWenn.LobbyUICode.GDChest3Objects4.length = 0;
ByteZhenWenn.LobbyUICode.GDChest3Objects5.length = 0;
ByteZhenWenn.LobbyUICode.GDChest3Objects6.length = 0;
ByteZhenWenn.LobbyUICode.GDChest3Objects7.length = 0;
ByteZhenWenn.LobbyUICode.GDChest3Objects8.length = 0;
ByteZhenWenn.LobbyUICode.GDChest4Objects1.length = 0;
ByteZhenWenn.LobbyUICode.GDChest4Objects2.length = 0;
ByteZhenWenn.LobbyUICode.GDChest4Objects3.length = 0;
ByteZhenWenn.LobbyUICode.GDChest4Objects4.length = 0;
ByteZhenWenn.LobbyUICode.GDChest4Objects5.length = 0;
ByteZhenWenn.LobbyUICode.GDChest4Objects6.length = 0;
ByteZhenWenn.LobbyUICode.GDChest4Objects7.length = 0;
ByteZhenWenn.LobbyUICode.GDChest4Objects8.length = 0;
ByteZhenWenn.LobbyUICode.GDChest5Objects1.length = 0;
ByteZhenWenn.LobbyUICode.GDChest5Objects2.length = 0;
ByteZhenWenn.LobbyUICode.GDChest5Objects3.length = 0;
ByteZhenWenn.LobbyUICode.GDChest5Objects4.length = 0;
ByteZhenWenn.LobbyUICode.GDChest5Objects5.length = 0;
ByteZhenWenn.LobbyUICode.GDChest5Objects6.length = 0;
ByteZhenWenn.LobbyUICode.GDChest5Objects7.length = 0;
ByteZhenWenn.LobbyUICode.GDChest5Objects8.length = 0;
ByteZhenWenn.LobbyUICode.GDChest6Objects1.length = 0;
ByteZhenWenn.LobbyUICode.GDChest6Objects2.length = 0;
ByteZhenWenn.LobbyUICode.GDChest6Objects3.length = 0;
ByteZhenWenn.LobbyUICode.GDChest6Objects4.length = 0;
ByteZhenWenn.LobbyUICode.GDChest6Objects5.length = 0;
ByteZhenWenn.LobbyUICode.GDChest6Objects6.length = 0;
ByteZhenWenn.LobbyUICode.GDChest6Objects7.length = 0;
ByteZhenWenn.LobbyUICode.GDChest6Objects8.length = 0;
ByteZhenWenn.LobbyUICode.GDChest7Objects1.length = 0;
ByteZhenWenn.LobbyUICode.GDChest7Objects2.length = 0;
ByteZhenWenn.LobbyUICode.GDChest7Objects3.length = 0;
ByteZhenWenn.LobbyUICode.GDChest7Objects4.length = 0;
ByteZhenWenn.LobbyUICode.GDChest7Objects5.length = 0;
ByteZhenWenn.LobbyUICode.GDChest7Objects6.length = 0;
ByteZhenWenn.LobbyUICode.GDChest7Objects7.length = 0;
ByteZhenWenn.LobbyUICode.GDChest7Objects8.length = 0;
ByteZhenWenn.LobbyUICode.GDChest8Objects1.length = 0;
ByteZhenWenn.LobbyUICode.GDChest8Objects2.length = 0;
ByteZhenWenn.LobbyUICode.GDChest8Objects3.length = 0;
ByteZhenWenn.LobbyUICode.GDChest8Objects4.length = 0;
ByteZhenWenn.LobbyUICode.GDChest8Objects5.length = 0;
ByteZhenWenn.LobbyUICode.GDChest8Objects6.length = 0;
ByteZhenWenn.LobbyUICode.GDChest8Objects7.length = 0;
ByteZhenWenn.LobbyUICode.GDChest8Objects8.length = 0;
ByteZhenWenn.LobbyUICode.GDChest9Objects1.length = 0;
ByteZhenWenn.LobbyUICode.GDChest9Objects2.length = 0;
ByteZhenWenn.LobbyUICode.GDChest9Objects3.length = 0;
ByteZhenWenn.LobbyUICode.GDChest9Objects4.length = 0;
ByteZhenWenn.LobbyUICode.GDChest9Objects5.length = 0;
ByteZhenWenn.LobbyUICode.GDChest9Objects6.length = 0;
ByteZhenWenn.LobbyUICode.GDChest9Objects7.length = 0;
ByteZhenWenn.LobbyUICode.GDChest9Objects8.length = 0;
ByteZhenWenn.LobbyUICode.GDChestExplosionObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDChestExplosionObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDChestExplosionObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDChestExplosionObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDChestExplosionObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDChestExplosionObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDChestExplosionObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDChestExplosionObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDSquirelBonusObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDSquirelBonusObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDSquirelBonusObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDSquirelBonusObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDSquirelBonusObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDSquirelBonusObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDSquirelBonusObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDSquirelBonusObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDLeafParticleObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDLeafParticleObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDLeafParticleObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDLeafParticleObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDLeafParticleObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDLeafParticleObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDLeafParticleObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDLeafParticleObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDsunlightObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDsunlightObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDsunlightObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDsunlightObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDsunlightObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDsunlightObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDsunlightObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDsunlightObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle2XObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle2XObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle2XObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle2XObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle2XObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle2XObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle2XObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle2XObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle5XObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle5XObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle5XObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle5XObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle5XObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle5XObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle5XObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle5XObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle10XObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle10XObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle10XObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle10XObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle10XObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle10XObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle10XObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle10XObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle3XObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle3XObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle3XObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle3XObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle3XObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle3XObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle3XObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle3XObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDNewLightObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDNewLightObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDNewLightObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDNewLightObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDNewLightObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDNewLightObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDNewLightObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDNewLightObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDDepositButtonObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDDepositButtonObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDDepositButtonObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDDepositButtonObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDDepositButtonObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDDepositButtonObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDDepositButtonObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDDepositButtonObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDBetModalObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDBetModalObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDBetModalObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDBetModalObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDBetModalObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDBetModalObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDBetModalObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDBetModalObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDWinModalObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDWinModalObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDWinModalObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDWinModalObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDWinModalObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDWinModalObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDWinModalObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDWinModalObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595rulesObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595rulesObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595rulesObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595rulesObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595rulesObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595rulesObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595rulesObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595rulesObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595rules_9595txtObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595rules_9595txtObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595rules_9595txtObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595rules_9595txtObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595rules_9595txtObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595rules_9595txtObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595rules_9595txtObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595rules_9595txtObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595soundObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595soundObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595soundObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595soundObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595soundObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595soundObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595soundObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595soundObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595sound_9595txtObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595sound_9595txtObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595sound_9595txtObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595sound_9595txtObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595sound_9595txtObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595sound_9595txtObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595sound_9595txtObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595sound_9595txtObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDGoldKeyObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDGoldKeyObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDGoldKeyObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDGoldKeyObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDGoldKeyObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDGoldKeyObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDGoldKeyObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDGoldKeyObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDProfileObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDProfileObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDProfileObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDProfileObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDProfileObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDProfileObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDProfileObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDProfileObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDPerfilObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDPerfilObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDPerfilObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDPerfilObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDPerfilObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDPerfilObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDPerfilObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDPerfilObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959500Objects1.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959500Objects2.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959500Objects3.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959500Objects4.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959500Objects5.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959500Objects6.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959500Objects7.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959500Objects8.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959501Objects1.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959501Objects2.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959501Objects3.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959501Objects4.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959501Objects5.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959501Objects6.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959501Objects7.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959501Objects8.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959502Objects1.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959502Objects2.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959502Objects3.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959502Objects4.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959502Objects5.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959502Objects6.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959502Objects7.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959502Objects8.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959503Objects1.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959503Objects2.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959503Objects3.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959503Objects4.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959503Objects5.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959503Objects6.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959503Objects7.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959503Objects8.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959504Objects1.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959504Objects2.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959504Objects3.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959504Objects4.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959504Objects5.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959504Objects6.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959504Objects7.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959504Objects8.length = 0;
ByteZhenWenn.LobbyUICode.GDcoin_9595particleObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDcoin_9595particleObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDcoin_9595particleObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDcoin_9595particleObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDcoin_9595particleObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDcoin_9595particleObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDcoin_9595particleObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDcoin_9595particleObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDcoin_9595trailObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDcoin_9595trailObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDcoin_9595trailObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDcoin_9595trailObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDcoin_9595trailObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDcoin_9595trailObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDcoin_9595trailObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDcoin_9595trailObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_9595foxObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_9595foxObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_9595foxObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_9595foxObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_9595foxObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_9595foxObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_9595foxObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_9595foxObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDFoxHitObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDFoxHitObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDFoxHitObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDFoxHitObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDFoxHitObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDFoxHitObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDFoxHitObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDFoxHitObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDChestCollectObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDChestCollectObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDChestCollectObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDChestCollectObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDChestCollectObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDChestCollectObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDChestCollectObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDChestCollectObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDcollect_9595textObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDcollect_9595textObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDcollect_9595textObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDcollect_9595textObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDcollect_9595textObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDcollect_9595textObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDcollect_9595textObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDcollect_9595textObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDBonusGreenBallObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDBonusGreenBallObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDBonusGreenBallObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDBonusGreenBallObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDBonusGreenBallObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDBonusGreenBallObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDBonusGreenBallObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDBonusGreenBallObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDSunBonuseObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDSunBonuseObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDSunBonuseObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDSunBonuseObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDSunBonuseObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDSunBonuseObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDSunBonuseObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDSunBonuseObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trailObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trailObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trailObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trailObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trailObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trailObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trailObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trailObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trail2Objects1.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trail2Objects2.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trail2Objects3.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trail2Objects4.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trail2Objects5.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trail2Objects6.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trail2Objects7.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trail2Objects8.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trail3Objects1.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trail3Objects2.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trail3Objects3.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trail3Objects4.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trail3Objects5.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trail3Objects6.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trail3Objects7.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trail3Objects8.length = 0;
ByteZhenWenn.LobbyUICode.GDModalGoldObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDModalGoldObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDModalGoldObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDModalGoldObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDModalGoldObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDModalGoldObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDModalGoldObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDModalGoldObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDSensationalUIObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDSensationalUIObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDSensationalUIObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDSensationalUIObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDSensationalUIObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDSensationalUIObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDSensationalUIObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDSensationalUIObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSprite2Objects1.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSprite2Objects2.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSprite2Objects3.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSprite2Objects4.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSprite2Objects5.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSprite2Objects6.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSprite2Objects7.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSprite2Objects8.length = 0;
ByteZhenWenn.LobbyUICode.GDReceiveWinObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDReceiveWinObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDReceiveWinObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDReceiveWinObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDReceiveWinObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDReceiveWinObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDReceiveWinObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDReceiveWinObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDCoinPopUpObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDCoinPopUpObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDCoinPopUpObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDCoinPopUpObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDCoinPopUpObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDCoinPopUpObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDCoinPopUpObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDCoinPopUpObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierXObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierXObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierXObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierXObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierXObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierXObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierXObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierXObjects8.length = 0;

ByteZhenWenn.LobbyUICode.eventsList61(runtimeScene);
ByteZhenWenn.LobbyUICode.GDGameBackgrondObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDGameBackgrondObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDGameBackgrondObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDGameBackgrondObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDGameBackgrondObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDGameBackgrondObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDGameBackgrondObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDGameBackgrondObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDLogoObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDLogoObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDLogoObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDLogoObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDLogoObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDLogoObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDLogoObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDLogoObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDHeader_9595UIObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDHeader_9595UIObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDHeader_9595UIObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDHeader_9595UIObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDHeader_9595UIObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDHeader_9595UIObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDHeader_9595UIObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDHeader_9595UIObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDPlayerIDObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDPlayerIDObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDPlayerIDObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDPlayerIDObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDPlayerIDObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDPlayerIDObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDPlayerIDObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDPlayerIDObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDPlayerBalanceObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDPlayerBalanceObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDPlayerBalanceObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDPlayerBalanceObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDPlayerBalanceObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDPlayerBalanceObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDPlayerBalanceObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDPlayerBalanceObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDIndiqueGanheObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDIndiqueGanheObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDIndiqueGanheObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDIndiqueGanheObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDIndiqueGanheObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDIndiqueGanheObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDIndiqueGanheObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDIndiqueGanheObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDGasObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDGasObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDGasObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDGasObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDGasObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDGasObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDGasObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDGasObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSpriteObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSpriteObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSpriteObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSpriteObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSpriteObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSpriteObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSpriteObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSpriteObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDUi_9595SOCIALObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDUi_9595SOCIALObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDUi_9595SOCIALObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDUi_9595SOCIALObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDUi_9595SOCIALObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDUi_9595SOCIALObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDUi_9595SOCIALObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDUi_9595SOCIALObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDUI_9595SupportObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDUI_9595SupportObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDUI_9595SupportObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDUI_9595SupportObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDUI_9595SupportObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDUI_9595SupportObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDUI_9595SupportObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDUI_9595SupportObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDSquirrelIdleObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDSquirrelIdleObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDSquirrelIdleObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDSquirrelIdleObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDSquirrelIdleObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDSquirrelIdleObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDSquirrelIdleObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDSquirrelIdleObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDPowerBallObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDPowerBallObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDPowerBallObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDPowerBallObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDPowerBallObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDPowerBallObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDPowerBallObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDPowerBallObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDBlueFlameObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDBlueFlameObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDBlueFlameObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDBlueFlameObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDBlueFlameObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDBlueFlameObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDBlueFlameObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDBlueFlameObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinMainButtonObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinMainButtonObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinMainButtonObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinMainButtonObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinMainButtonObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinMainButtonObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinMainButtonObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinMainButtonObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSprite3Objects1.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSprite3Objects2.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSprite3Objects3.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSprite3Objects4.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSprite3Objects5.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSprite3Objects6.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSprite3Objects7.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSprite3Objects8.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinButtonObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinButtonObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinButtonObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinButtonObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinButtonObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinButtonObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinButtonObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinButtonObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDPlusObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDPlusObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDPlusObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDPlusObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDPlusObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDPlusObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDPlusObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDPlusObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDMinusObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDMinusObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDMinusObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDMinusObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDMinusObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDMinusObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDMinusObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDMinusObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDBetAmountObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDBetAmountObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDBetAmountObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDBetAmountObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDBetAmountObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDBetAmountObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDBetAmountObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDBetAmountObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDWinAmountObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDWinAmountObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDWinAmountObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDWinAmountObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDWinAmountObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDWinAmountObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDWinAmountObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDWinAmountObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDLockObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDLockObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDLockObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDLockObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDLockObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDLockObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDLockObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDLockObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinMagicObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinMagicObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinMagicObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinMagicObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinMagicObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinMagicObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinMagicObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDSpinMagicObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDPulseParticleObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDPulseParticleObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDPulseParticleObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDPulseParticleObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDPulseParticleObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDPulseParticleObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDPulseParticleObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDPulseParticleObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDChest1Objects1.length = 0;
ByteZhenWenn.LobbyUICode.GDChest1Objects2.length = 0;
ByteZhenWenn.LobbyUICode.GDChest1Objects3.length = 0;
ByteZhenWenn.LobbyUICode.GDChest1Objects4.length = 0;
ByteZhenWenn.LobbyUICode.GDChest1Objects5.length = 0;
ByteZhenWenn.LobbyUICode.GDChest1Objects6.length = 0;
ByteZhenWenn.LobbyUICode.GDChest1Objects7.length = 0;
ByteZhenWenn.LobbyUICode.GDChest1Objects8.length = 0;
ByteZhenWenn.LobbyUICode.GDChest2Objects1.length = 0;
ByteZhenWenn.LobbyUICode.GDChest2Objects2.length = 0;
ByteZhenWenn.LobbyUICode.GDChest2Objects3.length = 0;
ByteZhenWenn.LobbyUICode.GDChest2Objects4.length = 0;
ByteZhenWenn.LobbyUICode.GDChest2Objects5.length = 0;
ByteZhenWenn.LobbyUICode.GDChest2Objects6.length = 0;
ByteZhenWenn.LobbyUICode.GDChest2Objects7.length = 0;
ByteZhenWenn.LobbyUICode.GDChest2Objects8.length = 0;
ByteZhenWenn.LobbyUICode.GDChest3Objects1.length = 0;
ByteZhenWenn.LobbyUICode.GDChest3Objects2.length = 0;
ByteZhenWenn.LobbyUICode.GDChest3Objects3.length = 0;
ByteZhenWenn.LobbyUICode.GDChest3Objects4.length = 0;
ByteZhenWenn.LobbyUICode.GDChest3Objects5.length = 0;
ByteZhenWenn.LobbyUICode.GDChest3Objects6.length = 0;
ByteZhenWenn.LobbyUICode.GDChest3Objects7.length = 0;
ByteZhenWenn.LobbyUICode.GDChest3Objects8.length = 0;
ByteZhenWenn.LobbyUICode.GDChest4Objects1.length = 0;
ByteZhenWenn.LobbyUICode.GDChest4Objects2.length = 0;
ByteZhenWenn.LobbyUICode.GDChest4Objects3.length = 0;
ByteZhenWenn.LobbyUICode.GDChest4Objects4.length = 0;
ByteZhenWenn.LobbyUICode.GDChest4Objects5.length = 0;
ByteZhenWenn.LobbyUICode.GDChest4Objects6.length = 0;
ByteZhenWenn.LobbyUICode.GDChest4Objects7.length = 0;
ByteZhenWenn.LobbyUICode.GDChest4Objects8.length = 0;
ByteZhenWenn.LobbyUICode.GDChest5Objects1.length = 0;
ByteZhenWenn.LobbyUICode.GDChest5Objects2.length = 0;
ByteZhenWenn.LobbyUICode.GDChest5Objects3.length = 0;
ByteZhenWenn.LobbyUICode.GDChest5Objects4.length = 0;
ByteZhenWenn.LobbyUICode.GDChest5Objects5.length = 0;
ByteZhenWenn.LobbyUICode.GDChest5Objects6.length = 0;
ByteZhenWenn.LobbyUICode.GDChest5Objects7.length = 0;
ByteZhenWenn.LobbyUICode.GDChest5Objects8.length = 0;
ByteZhenWenn.LobbyUICode.GDChest6Objects1.length = 0;
ByteZhenWenn.LobbyUICode.GDChest6Objects2.length = 0;
ByteZhenWenn.LobbyUICode.GDChest6Objects3.length = 0;
ByteZhenWenn.LobbyUICode.GDChest6Objects4.length = 0;
ByteZhenWenn.LobbyUICode.GDChest6Objects5.length = 0;
ByteZhenWenn.LobbyUICode.GDChest6Objects6.length = 0;
ByteZhenWenn.LobbyUICode.GDChest6Objects7.length = 0;
ByteZhenWenn.LobbyUICode.GDChest6Objects8.length = 0;
ByteZhenWenn.LobbyUICode.GDChest7Objects1.length = 0;
ByteZhenWenn.LobbyUICode.GDChest7Objects2.length = 0;
ByteZhenWenn.LobbyUICode.GDChest7Objects3.length = 0;
ByteZhenWenn.LobbyUICode.GDChest7Objects4.length = 0;
ByteZhenWenn.LobbyUICode.GDChest7Objects5.length = 0;
ByteZhenWenn.LobbyUICode.GDChest7Objects6.length = 0;
ByteZhenWenn.LobbyUICode.GDChest7Objects7.length = 0;
ByteZhenWenn.LobbyUICode.GDChest7Objects8.length = 0;
ByteZhenWenn.LobbyUICode.GDChest8Objects1.length = 0;
ByteZhenWenn.LobbyUICode.GDChest8Objects2.length = 0;
ByteZhenWenn.LobbyUICode.GDChest8Objects3.length = 0;
ByteZhenWenn.LobbyUICode.GDChest8Objects4.length = 0;
ByteZhenWenn.LobbyUICode.GDChest8Objects5.length = 0;
ByteZhenWenn.LobbyUICode.GDChest8Objects6.length = 0;
ByteZhenWenn.LobbyUICode.GDChest8Objects7.length = 0;
ByteZhenWenn.LobbyUICode.GDChest8Objects8.length = 0;
ByteZhenWenn.LobbyUICode.GDChest9Objects1.length = 0;
ByteZhenWenn.LobbyUICode.GDChest9Objects2.length = 0;
ByteZhenWenn.LobbyUICode.GDChest9Objects3.length = 0;
ByteZhenWenn.LobbyUICode.GDChest9Objects4.length = 0;
ByteZhenWenn.LobbyUICode.GDChest9Objects5.length = 0;
ByteZhenWenn.LobbyUICode.GDChest9Objects6.length = 0;
ByteZhenWenn.LobbyUICode.GDChest9Objects7.length = 0;
ByteZhenWenn.LobbyUICode.GDChest9Objects8.length = 0;
ByteZhenWenn.LobbyUICode.GDChestExplosionObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDChestExplosionObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDChestExplosionObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDChestExplosionObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDChestExplosionObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDChestExplosionObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDChestExplosionObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDChestExplosionObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDSquirelBonusObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDSquirelBonusObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDSquirelBonusObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDSquirelBonusObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDSquirelBonusObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDSquirelBonusObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDSquirelBonusObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDSquirelBonusObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDLeafParticleObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDLeafParticleObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDLeafParticleObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDLeafParticleObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDLeafParticleObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDLeafParticleObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDLeafParticleObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDLeafParticleObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDsunlightObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDsunlightObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDsunlightObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDsunlightObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDsunlightObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDsunlightObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDsunlightObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDsunlightObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle2XObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle2XObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle2XObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle2XObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle2XObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle2XObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle2XObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle2XObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle5XObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle5XObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle5XObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle5XObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle5XObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle5XObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle5XObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle5XObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle10XObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle10XObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle10XObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle10XObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle10XObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle10XObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle10XObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle10XObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle3XObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle3XObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle3XObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle3XObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle3XObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle3XObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle3XObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDMultiplierParticle3XObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDNewLightObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDNewLightObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDNewLightObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDNewLightObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDNewLightObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDNewLightObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDNewLightObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDNewLightObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDDepositButtonObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDDepositButtonObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDDepositButtonObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDDepositButtonObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDDepositButtonObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDDepositButtonObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDDepositButtonObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDDepositButtonObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDBetModalObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDBetModalObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDBetModalObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDBetModalObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDBetModalObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDBetModalObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDBetModalObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDBetModalObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDWinModalObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDWinModalObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDWinModalObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDWinModalObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDWinModalObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDWinModalObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDWinModalObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDWinModalObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595rulesObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595rulesObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595rulesObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595rulesObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595rulesObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595rulesObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595rulesObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595rulesObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595rules_9595txtObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595rules_9595txtObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595rules_9595txtObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595rules_9595txtObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595rules_9595txtObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595rules_9595txtObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595rules_9595txtObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595rules_9595txtObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595soundObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595soundObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595soundObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595soundObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595soundObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595soundObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595soundObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595soundObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595sound_9595txtObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595sound_9595txtObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595sound_9595txtObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595sound_9595txtObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595sound_9595txtObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595sound_9595txtObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595sound_9595txtObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDui_9595sound_9595txtObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDGoldKeyObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDGoldKeyObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDGoldKeyObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDGoldKeyObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDGoldKeyObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDGoldKeyObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDGoldKeyObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDGoldKeyObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDProfileObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDProfileObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDProfileObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDProfileObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDProfileObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDProfileObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDProfileObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDProfileObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDPerfilObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDPerfilObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDPerfilObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDPerfilObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDPerfilObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDPerfilObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDPerfilObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDPerfilObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959500Objects1.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959500Objects2.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959500Objects3.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959500Objects4.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959500Objects5.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959500Objects6.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959500Objects7.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959500Objects8.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959501Objects1.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959501Objects2.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959501Objects3.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959501Objects4.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959501Objects5.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959501Objects6.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959501Objects7.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959501Objects8.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959502Objects1.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959502Objects2.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959502Objects3.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959502Objects4.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959502Objects5.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959502Objects6.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959502Objects7.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959502Objects8.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959503Objects1.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959503Objects2.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959503Objects3.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959503Objects4.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959503Objects5.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959503Objects6.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959503Objects7.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959503Objects8.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959504Objects1.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959504Objects2.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959504Objects3.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959504Objects4.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959504Objects5.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959504Objects6.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959504Objects7.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_959504Objects8.length = 0;
ByteZhenWenn.LobbyUICode.GDcoin_9595particleObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDcoin_9595particleObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDcoin_9595particleObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDcoin_9595particleObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDcoin_9595particleObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDcoin_9595particleObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDcoin_9595particleObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDcoin_9595particleObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDcoin_9595trailObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDcoin_9595trailObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDcoin_9595trailObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDcoin_9595trailObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDcoin_9595trailObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDcoin_9595trailObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDcoin_9595trailObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDcoin_9595trailObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_9595foxObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_9595foxObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_9595foxObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_9595foxObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_9595foxObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_9595foxObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_9595foxObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDprize_9595foxObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDFoxHitObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDFoxHitObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDFoxHitObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDFoxHitObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDFoxHitObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDFoxHitObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDFoxHitObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDFoxHitObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDChestCollectObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDChestCollectObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDChestCollectObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDChestCollectObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDChestCollectObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDChestCollectObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDChestCollectObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDChestCollectObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDcollect_9595textObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDcollect_9595textObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDcollect_9595textObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDcollect_9595textObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDcollect_9595textObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDcollect_9595textObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDcollect_9595textObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDcollect_9595textObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDBonusGreenBallObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDBonusGreenBallObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDBonusGreenBallObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDBonusGreenBallObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDBonusGreenBallObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDBonusGreenBallObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDBonusGreenBallObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDBonusGreenBallObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDSunBonuseObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDSunBonuseObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDSunBonuseObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDSunBonuseObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDSunBonuseObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDSunBonuseObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDSunBonuseObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDSunBonuseObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trailObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trailObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trailObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trailObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trailObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trailObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trailObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trailObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trail2Objects1.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trail2Objects2.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trail2Objects3.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trail2Objects4.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trail2Objects5.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trail2Objects6.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trail2Objects7.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trail2Objects8.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trail3Objects1.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trail3Objects2.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trail3Objects3.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trail3Objects4.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trail3Objects5.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trail3Objects6.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trail3Objects7.length = 0;
ByteZhenWenn.LobbyUICode.GDbonus_9595trail3Objects8.length = 0;
ByteZhenWenn.LobbyUICode.GDModalGoldObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDModalGoldObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDModalGoldObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDModalGoldObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDModalGoldObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDModalGoldObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDModalGoldObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDModalGoldObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDSensationalUIObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDSensationalUIObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDSensationalUIObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDSensationalUIObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDSensationalUIObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDSensationalUIObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDSensationalUIObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDSensationalUIObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSprite2Objects1.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSprite2Objects2.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSprite2Objects3.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSprite2Objects4.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSprite2Objects5.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSprite2Objects6.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSprite2Objects7.length = 0;
ByteZhenWenn.LobbyUICode.GDNewSprite2Objects8.length = 0;
ByteZhenWenn.LobbyUICode.GDReceiveWinObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDReceiveWinObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDReceiveWinObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDReceiveWinObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDReceiveWinObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDReceiveWinObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDReceiveWinObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDReceiveWinObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDCoinPopUpObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDCoinPopUpObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDCoinPopUpObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDCoinPopUpObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDCoinPopUpObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDCoinPopUpObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDCoinPopUpObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDCoinPopUpObjects8.length = 0;
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierXObjects1.length = 0;
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierXObjects2.length = 0;
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierXObjects3.length = 0;
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierXObjects4.length = 0;
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierXObjects5.length = 0;
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierXObjects6.length = 0;
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierXObjects7.length = 0;
ByteZhenWenn.LobbyUICode.GDBonuseMultiplierXObjects8.length = 0;


return;

}

ByteZhenWenn['LobbyUICode'] = ByteZhenWenn.LobbyUICode;
