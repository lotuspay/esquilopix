  
    <!-- All javascirpt -->
    <!-- Alpine js -->
    <script src="assets/js/alpine-collaspe.min.js"></script>
    <script src="assets/js/alpine-persist.min.js"></script>
    <script src="assets/js/alpine.min.js" defer></script>

    <!-- ApexCharts js -->
    <script src="assets/js/apexcharts.js"></script>
    <script src="assets/js/apexcharts-main.js"></script>

    <!-- Custom js -->
    <script src="assets/js/custom.js"></script>