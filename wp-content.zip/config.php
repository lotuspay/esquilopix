<?php

define('DASH', 'dash');

// Definir pasta URL padrão se não estiver definida
if (!isset($pasta_url)) {
    $pasta_url = '';
}